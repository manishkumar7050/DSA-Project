@echo off
REM Compiles and starts the Coupon & Discount Manager (GUI). Double-click or run from the VS Code terminal.
cd /d "%~dp0"
if not exist out mkdir out
javac -d out *.java
if errorlevel 1 (
    echo.
    echo Compilation failed. Check that JDK is installed and "javac" works in this terminal.
    pause
    exit /b 1
)
java -cp out CouponApp %*
