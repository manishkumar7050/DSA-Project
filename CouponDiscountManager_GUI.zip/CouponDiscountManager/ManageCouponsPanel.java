import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableColumnModel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.util.List;

/** Screen 4: all coupons in a JTable with search, sort and refresh. */
public class ManageCouponsPanel extends JPanel {
    private final CouponManager manager;
    private final CouponTableModel tableModel;
    private final JTable table;
    private final JTextField searchField = Theme.fieldText(18);
    private final JComboBox<CouponManager.SortBy> sortCombo = new JComboBox<>(CouponManager.SortBy.values());
    private final JLabel countLabel = Theme.label(" ", 12, Font.PLAIN, Theme.MUTED);

    public ManageCouponsPanel(CouponManager manager) {
        this.manager = manager;
        this.tableModel = new CouponTableModel(manager.getToday(), false);
        this.table = new JTable(tableModel);
        setLayout(new BorderLayout(0, 16));
        Theme.stylePage(this);

        table.setName("manageTable");
        searchField.setName("manageSearch");
        sortCombo.setName("manageSort");
        countLabel.setName("manageCount");

        add(Theme.pageHeader("Manage Coupons",
                "Search the coupons, change the sort order and see the status of every coupon."), BorderLayout.NORTH);

        Theme.RoundedPanel card = Theme.card();
        card.setLayout(new BorderLayout(0, 12));
        card.add(buildToolbar(), BorderLayout.NORTH);

        Theme.styleTable(table, CouponTableModel.STATUS_COLUMN, Theme::statusColor);
        TableColumnModel columns = table.getColumnModel();
        int[] widths = {160, 120, 130, 130, 110, 110};
        for (int i = 0; i < widths.length; i++) {
            columns.getColumn(i).setPreferredWidth(widths[i]);
        }
        columns.getColumn(CouponTableModel.STATUS_COLUMN).setMinWidth(100);   // "Upcoming" must fit
        card.add(Theme.scrollable(table), BorderLayout.CENTER);
        card.add(countLabel, BorderLayout.SOUTH);
        add(card, BorderLayout.CENTER);

        sortCombo.addActionListener(e -> reload());
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { reload(); }
            @Override public void removeUpdate(DocumentEvent e) { reload(); }
            @Override public void changedUpdate(DocumentEvent e) { reload(); }
        });
        reload();
    }

    private JPanel buildToolbar() {
        Theme.styleCombo(sortCombo);
        sortCombo.setPreferredSize(new Dimension(270, 38));
        JButton refreshButton = Theme.primaryButton("Refresh");
        refreshButton.setName("manageRefresh");
        refreshButton.addActionListener(e -> {
            reload();
            countLabel.setText(countLabel.getText() + "   (list refreshed)");
        });
        JButton clearSearch = Theme.secondaryButton("Clear Search");
        clearSearch.setName("manageClear");
        clearSearch.addActionListener(e -> searchField.setText(""));

        JPanel bar = new JPanel();
        bar.setOpaque(false);
        bar.setLayout(new BoxLayout(bar, BoxLayout.X_AXIS));
        bar.add(labelled("SEARCH (code, type or status)", searchField));
        bar.add(Box.createRigidArea(new Dimension(10, 0)));
        bar.add(clearSearch);
        bar.add(Box.createRigidArea(new Dimension(22, 0)));
        bar.add(labelled("SORT BY", sortCombo));
        bar.add(Box.createHorizontalGlue());
        bar.add(refreshButton);
        return bar;
    }

    private JPanel labelled(String caption, javax.swing.JComponent field) {
        JPanel p = new JPanel(new BorderLayout(0, 4));
        p.setOpaque(false);
        p.add(Theme.fieldLabel(caption), BorderLayout.NORTH);
        p.add(field, BorderLayout.CENTER);
        p.setMaximumSize(new Dimension(320, 70));
        return p;
    }

    /** Called when data changes or the screen is opened. */
    public void refresh() {
        reload();
    }

    private void reload() {
        CouponManager.SortBy sortBy = (CouponManager.SortBy) sortCombo.getSelectedItem();
        List<Coupon> shown = manager.searchCoupons(searchField.getText(), sortBy);
        tableModel.setCoupons(shown);
        String text = "Showing " + shown.size() + " of " + manager.getTotalCount() + " coupon(s)";
        if (!searchField.getText().trim().isEmpty()) {
            text += " matching \"" + searchField.getText().trim() + "\"";
        }
        countLabel.setText(text);
    }
}
