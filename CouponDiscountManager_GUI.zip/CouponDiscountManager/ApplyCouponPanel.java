import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Screen 3: apply a typed coupon, or let the greedy strategy find the best coupon.
 * Shows a billing summary and a table that compares every coupon for this bill.
 */
public class ApplyCouponPanel extends JPanel {
    private static final String[] COMPARE_COLUMNS = {"Coupon", "Offer", "Saving on this bill", "Result"};

    private final CouponManager manager;
    private final Runnable onDataChanged;

    private final JTextField billField = Theme.fieldText(12);
    private final JTextField codeField = Theme.fieldText(12);
    private final JLabel inputMessage = Theme.label(" ", 12, Font.BOLD, Theme.MUTED);
    private final JLabel activeHint = Theme.label(" ", 12, Font.PLAIN, Theme.MUTED);

    private final JLabel resultBanner = Theme.label("Enter a bill amount and apply a coupon.", 13, Font.BOLD, Theme.MUTED);
    private final JLabel sumBill = valueLabel("-");
    private final JLabel sumCoupon = valueLabel("-");
    private final JLabel sumOffer = valueLabel("-");
    private final JLabel sumDiscount = valueLabel("-");
    private final JLabel sumFinal = Theme.label("-", 28, Font.BOLD, Theme.SUCCESS);

    private final DefaultTableModel compareModel = new DefaultTableModel(COMPARE_COLUMNS, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };

    /** One line of the comparison table. */
    private static class Row {
        final Coupon coupon;
        final double saving;       // -1 when the coupon cannot be used
        String result;

        Row(Coupon coupon, double saving, String result) {
            this.coupon = coupon;
            this.saving = saving;
            this.result = result;
        }
    }

    public ApplyCouponPanel(CouponManager manager, Runnable onDataChanged) {
        this.manager = manager;
        this.onDataChanged = onDataChanged;
        setLayout(new BorderLayout(0, 18));
        Theme.stylePage(this);

        billField.setName("applyBill");
        codeField.setName("applyCode");
        inputMessage.setName("applyInputMessage");
        resultBanner.setName("applyBanner");
        sumBill.setName("sumBill");
        sumCoupon.setName("sumCoupon");
        sumOffer.setName("sumOffer");
        sumDiscount.setName("sumDiscount");
        sumFinal.setName("sumFinal");

        add(Theme.pageHeader("Apply Coupon",
                "Apply a coupon code to a bill, or let the greedy strategy choose the best coupon automatically."),
                BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(0, 18));
        center.setOpaque(false);
        JPanel topRow = new JPanel(new GridLayout(1, 2, 18, 0));
        topRow.setOpaque(false);
        topRow.add(buildInputCard());
        topRow.add(buildSummaryCard());
        center.add(topRow, BorderLayout.NORTH);
        center.add(buildCompareCard(), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);
        refresh();
    }

    /** Only updates the hint. The billing summary is kept so the last result stays visible. */
    public void refresh() {
        activeHint.setText(manager.countByStatus(Coupon.STATUS_ACTIVE) + " active coupon(s) available today");
    }

    // ------------------------------------------------------------------ layout

    private static JLabel valueLabel(String text) {
        JLabel l = Theme.label(text, 14, Font.BOLD, Theme.TEXT);
        l.setHorizontalAlignment(SwingConstants.RIGHT);
        return l;
    }

    private JPanel buildInputCard() {
        Theme.RoundedPanel card = Theme.card();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));

        card.add(left(Theme.label("Bill Details", 17, Font.BOLD, Theme.TEXT)));
        card.add(Box.createRigidArea(new Dimension(0, 12)));
        card.add(left(Theme.fieldLabel("BILL AMOUNT")));
        card.add(Box.createRigidArea(new Dimension(0, 5)));
        card.add(left(fullWidth(billField)));
        card.add(Box.createRigidArea(new Dimension(0, 12)));
        card.add(left(Theme.fieldLabel("COUPON CODE (for Apply Coupon)")));
        card.add(Box.createRigidArea(new Dimension(0, 5)));
        card.add(left(fullWidth(codeField)));
        card.add(Box.createRigidArea(new Dimension(0, 16)));

        JButton applyButton = Theme.primaryButton("Apply Coupon");
        applyButton.setName("applyButton");
        applyButton.addActionListener(e -> apply(false));
        JButton bestButton = Theme.accentButton("Find Best Coupon");
        bestButton.setName("bestButton");
        bestButton.addActionListener(e -> apply(true));
        JButton clearButton = Theme.secondaryButton("Clear");
        clearButton.setName("applyClearButton");
        clearButton.addActionListener(e -> clearAll());
        billField.addActionListener(e -> apply(false));          // Enter key = Apply Coupon
        codeField.addActionListener(e -> apply(false));

        JPanel buttons = new JPanel();
        buttons.setOpaque(false);
        buttons.setLayout(new BoxLayout(buttons, BoxLayout.X_AXIS));
        buttons.add(applyButton);
        buttons.add(Box.createRigidArea(new Dimension(10, 0)));
        buttons.add(bestButton);
        buttons.add(Box.createRigidArea(new Dimension(10, 0)));
        buttons.add(clearButton);
        card.add(left(buttons));
        card.add(Box.createRigidArea(new Dimension(0, 10)));
        card.add(left(inputMessage));
        card.add(Box.createVerticalGlue());
        card.add(left(Theme.label("Find Best Coupon ignores the code box.",
                11, Font.PLAIN, Theme.MUTED)));
        card.add(left(activeHint));
        return card;
    }

    private JPanel buildSummaryCard() {
        Theme.RoundedPanel card = Theme.card();
        card.setLayout(new BorderLayout(0, 10));
        card.add(Theme.label("Billing Summary", 17, Font.BOLD, Theme.TEXT), BorderLayout.NORTH);

        JPanel rows = new JPanel(new GridBagLayout());
        rows.setOpaque(false);
        addSummaryRow(rows, 0, "Bill amount", sumBill);
        addSummaryRow(rows, 1, "Coupon used", sumCoupon);
        addSummaryRow(rows, 2, "Offer", sumOffer);
        addSummaryRow(rows, 3, "Discount amount", sumDiscount);

        GridBagConstraints line = new GridBagConstraints();
        line.gridx = 0; line.gridy = 4; line.gridwidth = 2; line.weightx = 1;
        line.fill = GridBagConstraints.HORIZONTAL;
        line.insets = new Insets(6, 0, 6, 0);
        javax.swing.JSeparator separator = new javax.swing.JSeparator();
        separator.setForeground(Theme.BORDER);
        rows.add(separator, line);

        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0; g.gridy = 5; g.anchor = GridBagConstraints.WEST;
        rows.add(Theme.label("Final payable amount", 14, Font.BOLD, Theme.TEXT), g);
        g.gridx = 1; g.weightx = 1; g.anchor = GridBagConstraints.EAST;
        rows.add(sumFinal, g);

        JPanel body = new JPanel(new BorderLayout(0, 10));
        body.setOpaque(false);
        body.add(resultBanner, BorderLayout.NORTH);
        body.add(rows, BorderLayout.CENTER);
        card.add(body, BorderLayout.CENTER);
        return card;
    }

    private void addSummaryRow(JPanel rows, int y, String caption, JLabel value) {
        GridBagConstraints g = new GridBagConstraints();
        g.gridy = y;
        g.insets = new Insets(4, 0, 4, 0);
        g.gridx = 0;
        g.anchor = GridBagConstraints.WEST;
        rows.add(Theme.label(caption, 13, Font.PLAIN, Theme.MUTED), g);
        g.gridx = 1;
        g.weightx = 1;
        g.anchor = GridBagConstraints.EAST;
        rows.add(value, g);
    }

    private JPanel buildCompareCard() {
        Theme.RoundedPanel card = Theme.card();
        card.setLayout(new BorderLayout(0, 10));
        JPanel title = new JPanel(new BorderLayout());
        title.setOpaque(false);
        title.add(Theme.label("Greedy Comparison", 17, Font.BOLD, Theme.TEXT), BorderLayout.WEST);
        title.add(Theme.label("Every coupon is checked once, O(n). The highest valid saving wins.",
                12, Font.PLAIN, Theme.MUTED), BorderLayout.SOUTH);
        card.add(title, BorderLayout.NORTH);

        JTable table = new JTable(compareModel);
        table.setName("compareTable");
        Theme.styleTable(table, 3, text -> {
            if (text.startsWith("Applied")) return Theme.PRIMARY_DARK;
            if (text.startsWith("Eligible")) return Theme.SUCCESS;
            return Theme.DANGER;
        });
        int[] widths = {110, 100, 150, 420};
        for (int i = 0; i < widths.length; i++) {
            table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }
        card.add(Theme.scrollable(table), BorderLayout.CENTER);
        return card;
    }

    private static <T extends javax.swing.JComponent> T left(T component) {
        component.setAlignmentX(LEFT_ALIGNMENT);
        return component;
    }

    private static JTextField fullWidth(JTextField field) {
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        return field;
    }

    // ------------------------------------------------------------------ actions

    private void clearAll() {
        billField.setText("");
        codeField.setText("");
        inputMessage.setText(" ");
        resultBanner.setText("Enter a bill amount and apply a coupon.");
        resultBanner.setForeground(Theme.MUTED);
        for (JLabel l : new JLabel[] {sumBill, sumCoupon, sumOffer, sumDiscount, sumFinal}) {
            l.setText("-");
        }
        compareModel.setRowCount(0);
    }

    private void showInputError(String message) {
        inputMessage.setText(message);
        inputMessage.setForeground(Theme.DANGER);
    }

    /** Reads the bill amount. Returns -1 (and shows a message) when it is not a valid positive number. */
    private double readBill() {
        String text = billField.getText().trim().replace(",", "");
        if (text.isEmpty()) {
            showInputError("Please enter the bill amount.");
            return -1;
        }
        if (!text.matches("\\d+(\\.\\d+)?")) {
            showInputError("Bill amount must be a number, for example 100 or 249.50.");
            return -1;
        }
        double bill = Double.parseDouble(text);
        if (!(bill > 0) || Double.isInfinite(bill)) {
            showInputError("Bill amount must be greater than 0.");
            return -1;
        }
        return bill;
    }

    /** @param auto true = greedy best coupon, false = use the code typed by the user */
    private void apply(boolean auto) {
        inputMessage.setText(" ");
        double bill = readBill();
        if (bill < 0) return;
        String code = codeField.getText().trim();
        if (!auto && code.isEmpty()) {
            showInputError("Enter a coupon code, or click Find Best Coupon.");
            return;
        }

        List<Row> rows = compareAllCoupons(bill);              // look at every coupon BEFORE the use is counted
        ApplyResult result = manager.apply(auto ? "" : code, bill);

        if (result.isSuccess()) {
            for (Row r : rows) {
                if (r.coupon.getCode().equals(result.getCouponCode())) r.result = "Applied";
            }
            Coupon used = manager.findCoupon(result.getCouponCode());
            sumCoupon.setText(result.getCouponCode() + (result.isAutoSelected() ? "  (auto-selected)" : ""));
            sumOffer.setText(used.describe());
            resultBanner.setText(result.getMessage());
            resultBanner.setForeground(Theme.SUCCESS);
            sumFinal.setForeground(Theme.SUCCESS);
            codeField.setText(result.isAutoSelected() ? result.getCouponCode() : codeField.getText().trim().toUpperCase());
        } else {
            sumCoupon.setText("-");
            sumOffer.setText("-");
            resultBanner.setText(result.getMessage() + "  No discount given.");
            resultBanner.setForeground(Theme.DANGER);
            sumFinal.setForeground(Theme.TEXT);
        }
        sumBill.setText(Coupon.format(result.getBillAmount()));
        sumDiscount.setText(Coupon.format(result.getDiscount()));
        sumFinal.setText(Coupon.format(result.getFinalBill()));
        fillCompareTable(rows);

        if (result.isSuccess()) {
            onDataChanged.run();                                // usage count changed: save and refresh screens
        }
    }

    /** Checks every coupon for this bill (what the greedy step looks at). */
    private List<Row> compareAllCoupons(double bill) {
        List<Row> rows = new ArrayList<>();
        for (Coupon c : manager.getCouponsSorted(CouponManager.SortBy.CODE_ASC)) {
            String reason = c.getInvalidReason(manager.getToday());
            if (reason == null) {
                rows.add(new Row(c, c.calculateDiscount(bill), "Eligible"));
            } else {
                rows.add(new Row(c, -1, "Not eligible: " + reason));
            }
        }
        return rows;
    }

    private void fillCompareTable(List<Row> rows) {
        rows.sort(Comparator.comparingDouble((Row r) -> r.saving).reversed());   // best saving first
        compareModel.setRowCount(0);
        for (Row r : rows) {
            compareModel.addRow(new Object[] {
                r.coupon.getCode(), r.coupon.describe(),
                r.saving < 0 ? "-" : Coupon.format(r.saving), r.result});
        }
    }
}
