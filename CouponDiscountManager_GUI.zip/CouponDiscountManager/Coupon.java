import java.time.LocalDate;

/**
 * Stores the details of one coupon.
 * Discount type is PERCENT (e.g. 10 means 10%) or FLAT (e.g. 15 means a fixed 15 off).
 */
public class Coupon {
    public static final String PERCENT = "PERCENT";
    public static final String FLAT = "FLAT";

    // Status names shown in the GUI (same checking order as getInvalidReason)
    public static final String STATUS_ACTIVE = "Active";
    public static final String STATUS_EXPIRED = "Expired";
    public static final String STATUS_UPCOMING = "Upcoming";
    public static final String STATUS_USED_UP = "Used up";

    private final String code;
    private final String discountType;
    private final double value;
    private final LocalDate startDate;
    private final LocalDate endDate;
    private final int usageLimit;
    private int usedCount;

    public Coupon(String code, String discountType, double value, LocalDate startDate,
                  LocalDate endDate, int usageLimit, int usedCount) {
        if (code == null || code.trim().isEmpty() || code.contains(",") || code.trim().contains(" ")) {
            throw new IllegalArgumentException("coupon code must not be empty or contain spaces or commas");
        }
        String type = discountType == null ? "" : discountType.trim().toUpperCase();
        if (!type.equals(PERCENT) && !type.equals(FLAT)) {
            throw new IllegalArgumentException("discount type must be PERCENT or FLAT");
        }
        if (!(value > 0) || Double.isInfinite(value)) {
            throw new IllegalArgumentException("discount value must be greater than 0");
        }
        if (type.equals(PERCENT) && value > 100) {
            throw new IllegalArgumentException("a percentage discount cannot be more than 100");
        }
        if (startDate == null || endDate == null || endDate.isBefore(startDate)) {
            throw new IllegalArgumentException("end date must not be before the start date");
        }
        if (usageLimit <= 0) {
            throw new IllegalArgumentException("usage limit must be at least 1");
        }
        if (usedCount < 0) {
            throw new IllegalArgumentException("used count cannot be negative");
        }
        this.code = code.trim().toUpperCase();
        this.discountType = type;
        this.value = value;
        this.startDate = startDate;
        this.endDate = endDate;
        this.usageLimit = usageLimit;
        this.usedCount = usedCount;
    }

    /** Creates a coupon from one line of coupons.txt:
     *  code,type,value,startDate,endDate,usageLimit,usedCount */
    public static Coupon fromFileLine(String line) {
        String[] p = line.split(",");
        if (p.length != 7) {
            throw new IllegalArgumentException("expected 7 comma-separated values but found " + p.length);
        }
        return new Coupon(p[0].trim(), p[1].trim(), Double.parseDouble(p[2].trim()),
                LocalDate.parse(p[3].trim()), LocalDate.parse(p[4].trim()),
                Integer.parseInt(p[5].trim()), Integer.parseInt(p[6].trim()));
    }

    /** Returns null when the coupon can be used on the given date, otherwise the reason it cannot. */
    public String getInvalidReason(LocalDate today) {
        if (today.isBefore(startDate)) return "it starts on " + startDate;
        if (today.isAfter(endDate)) return "it expired on " + endDate;
        if (usedCount >= usageLimit) return "its usage limit has been reached";
        return null;
    }

    /** One-word status of the coupon on the given date: Upcoming, Expired, Used up or Active. */
    public String getStatus(LocalDate today) {
        if (today.isBefore(startDate)) return STATUS_UPCOMING;
        if (today.isAfter(endDate)) return STATUS_EXPIRED;
        if (usedCount >= usageLimit) return STATUS_USED_UP;
        return STATUS_ACTIVE;
    }

    /** A coupon is valid only within its date range and while uses remain. */
    public boolean isValid(LocalDate today) {
        return getInvalidReason(today) == null;
    }

    /** Percentage: bill x value / 100. Flat: the fixed value. Never more than the bill amount. */
    public double calculateDiscount(double bill) {
        double discount = discountType.equals(PERCENT) ? bill * value / 100.0 : value;
        return Math.min(discount, bill);
    }

    public void incrementUsed() {
        usedCount++;
    }

    public String toFileLine() {
        return String.join(",", code, discountType, format(value), startDate.toString(),
                endDate.toString(), String.valueOf(usageLimit), String.valueOf(usedCount));
    }

    /** Short text such as "10%" or "15 flat". */
    public String describe() {
        return discountType.equals(PERCENT) ? format(value) + "%" : format(value) + " flat";
    }

    /** Prints whole numbers without ".0" (10.0 -> 10) and others with two decimals. */
    public static String format(double number) {
        if (number == Math.rint(number) && Math.abs(number) < 1e15) {
            return String.valueOf((long) number);
        }
        return String.format("%.2f", number);
    }

    public String getCode() { return code; }
    public String getDiscountType() { return discountType; }
    public double getValue() { return value; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public int getUsageLimit() { return usageLimit; }
    public int getUsedCount() { return usedCount; }
}
