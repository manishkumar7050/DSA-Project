import javax.swing.table.AbstractTableModel;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Table model that shows a list of coupons (used by the Manage and Report screens). */
public class CouponTableModel extends AbstractTableModel {
    public static final int STATUS_COLUMN = 5;

    private final LocalDate today;
    private final String[] columns;
    private final boolean withDetails;
    private List<Coupon> coupons = new ArrayList<>();

    /** @param withDetails true adds a "Details" column (uses left, or why the coupon is not valid) */
    public CouponTableModel(LocalDate today, boolean withDetails) {
        this.today = today;
        this.withDetails = withDetails;
        this.columns = withDetails
                ? new String[] {"Coupon Code", "Discount", "Start Date", "Expiry Date", "Used / Limit", "Status", "Details"}
                : new String[] {"Coupon Code", "Discount", "Start Date", "Expiry Date", "Used / Limit", "Status"};
    }

    public void setCoupons(List<Coupon> newCoupons) {
        this.coupons = new ArrayList<>(newCoupons);
        fireTableDataChanged();
    }

    public Coupon getCouponAt(int row) {
        return coupons.get(row);
    }

    @Override public int getRowCount() { return coupons.size(); }
    @Override public int getColumnCount() { return columns.length; }
    @Override public String getColumnName(int column) { return columns[column]; }

    @Override
    public Object getValueAt(int row, int column) {
        Coupon c = coupons.get(row);
        switch (column) {
            case 0: return c.getCode();
            case 1: return c.describe();
            case 2: return c.getStartDate().toString();
            case 3: return c.getEndDate().toString();
            case 4: return c.getUsedCount() + " / " + c.getUsageLimit();
            case 5: return c.getStatus(today);
            default:
                if (!withDetails) return "";
                String reason = c.getInvalidReason(today);
                if (reason == null) {
                    return (c.getUsageLimit() - c.getUsedCount()) + " use(s) left";
                }
                return Character.toUpperCase(reason.charAt(0)) + reason.substring(1);
        }
    }
}
