import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.time.format.DateTimeFormatter;
import java.util.function.Consumer;

/** Screen 1: welcome banner, coupon counts, navigation buttons and a summary of the DSA used. */
public class DashboardPanel extends JPanel {
    private final CouponManager manager;
    private final JLabel totalValue = Theme.label("0", 36, Font.BOLD, Theme.PRIMARY);
    private final JLabel activeValue = Theme.label("0", 36, Font.BOLD, Theme.SUCCESS);
    private final JLabel expiredValue = Theme.label("0", 36, Font.BOLD, Theme.DANGER);
    private final JLabel otherValue = Theme.label("0", 36, Font.BOLD, Theme.WARNING);
    private final JLabel treeInfo = Theme.label(" ", 12, Font.PLAIN, Theme.MUTED);

    public DashboardPanel(CouponManager manager, Consumer<String> navigator) {
        this.manager = manager;
        setLayout(new BorderLayout(0, 20));
        Theme.stylePage(this);

        totalValue.setName("dashTotal");
        activeValue.setName("dashActive");
        expiredValue.setName("dashExpired");
        otherValue.setName("dashOther");

        add(buildBanner(), BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(0, 20));
        center.setOpaque(false);
        center.add(buildStatRow(), BorderLayout.NORTH);
        center.add(buildLowerRow(navigator), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        refresh();
    }

    /** Reads the counts again from the manager. */
    public void refresh() {
        totalValue.setText(String.valueOf(manager.getTotalCount()));
        activeValue.setText(String.valueOf(manager.countByStatus(Coupon.STATUS_ACTIVE)));
        expiredValue.setText(String.valueOf(manager.countByStatus(Coupon.STATUS_EXPIRED)));
        otherValue.setText(String.valueOf(manager.countByStatus(Coupon.STATUS_UPCOMING)
                + manager.countByStatus(Coupon.STATUS_USED_UP)));
        treeInfo.setText("Live BST: " + manager.getTotalCount() + " node(s), " + manager.getBstHeight() + " level(s)");
    }

    private JPanel buildBanner() {
        Theme.GradientPanel banner = new Theme.GradientPanel();
        banner.setLayout(new BorderLayout(20, 0));
        banner.setBorder(new EmptyBorder(24, 30, 24, 30));

        JPanel text = new JPanel(new BorderLayout(0, 6));
        text.setOpaque(false);
        text.add(Theme.label("Coupon & Discount Manager", 30, Font.BOLD, Color.WHITE), BorderLayout.NORTH);
        text.add(Theme.label("Welcome! Add coupons, check their validity and always give the customer the best saving.",
                14, Font.PLAIN, new Color(0xE3ECFF)), BorderLayout.CENTER);
        banner.add(text, BorderLayout.CENTER);

        String date = manager.getToday().format(DateTimeFormatter.ofPattern("dd MMM yyyy"));
        JPanel dateBox = new JPanel(new BorderLayout(0, 2));
        dateBox.setOpaque(false);
        dateBox.add(Theme.label("Validity checked as of", 12, Font.PLAIN, new Color(0xCFE0FF)), BorderLayout.NORTH);
        dateBox.add(Theme.label(date, 18, Font.BOLD, Color.WHITE), BorderLayout.CENTER);
        banner.add(dateBox, BorderLayout.EAST);
        return banner;
    }

    private JPanel buildStatRow() {
        JPanel row = new JPanel(new GridLayout(1, 4, 16, 0));
        row.setOpaque(false);
        row.add(statCard("Total Coupons", totalValue, "Stored in BST + HashMap"));
        row.add(statCard("Active Coupons", activeValue, "Valid today, uses left"));
        row.add(statCard("Expired Coupons", expiredValue, "Past their end date"));
        row.add(statCard("Upcoming / Used Up", otherValue, "Not started / limit reached"));
        return row;
    }

    private JPanel statCard(String caption, JLabel value, String hint) {
        Theme.RoundedPanel card = Theme.card();
        card.setLayout(new BorderLayout(0, 4));
        card.add(Theme.label(caption, 13, Font.BOLD, Theme.MUTED), BorderLayout.NORTH);
        card.add(value, BorderLayout.CENTER);
        card.add(Theme.label(hint, 11, Font.PLAIN, Theme.MUTED), BorderLayout.SOUTH);
        return card;
    }

    private JPanel buildLowerRow(Consumer<String> navigator) {
        JPanel row = new JPanel(new GridLayout(1, 2, 16, 0));
        row.setOpaque(false);
        row.add(buildQuickActions(navigator));
        row.add(buildDsaCard());
        return row;
    }

    private JPanel buildQuickActions(Consumer<String> navigator) {
        Theme.RoundedPanel card = Theme.card();
        card.setLayout(new BorderLayout(0, 14));
        card.add(Theme.label("Quick Actions", 17, Font.BOLD, Theme.TEXT), BorderLayout.NORTH);

        JPanel buttons = new JPanel(new GridLayout(4, 1, 0, 12));
        buttons.setOpaque(false);
        buttons.add(navButton("Add a New Coupon", Theme.primaryButton("Add a New Coupon"), MainPanel.SCREEN_ADD, navigator));
        buttons.add(navButton("Apply Coupon to a Bill", Theme.accentButton("Apply Coupon to a Bill"), MainPanel.SCREEN_APPLY, navigator));
        buttons.add(navButton("Manage Coupons", Theme.secondaryButton("Manage Coupons"), MainPanel.SCREEN_MANAGE, navigator));
        buttons.add(navButton("View Reports", Theme.secondaryButton("View Reports"), MainPanel.SCREEN_REPORT, navigator));
        card.add(buttons, BorderLayout.CENTER);
        return card;
    }

    private JButton navButton(String name, JButton button, String screen, Consumer<String> navigator) {
        button.setName("dashGo" + screen.replace(" ", ""));
        button.addActionListener(e -> navigator.accept(screen));
        return button;
    }

    private JPanel buildDsaCard() {
        Theme.RoundedPanel card = Theme.card();
        card.setLayout(new BorderLayout(0, 12));
        card.add(Theme.label("DSA Concepts Used", 17, Font.BOLD, Theme.TEXT), BorderLayout.NORTH);

        JPanel list = new JPanel();
        list.setOpaque(false);
        list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));
        list.add(dsaRow("Binary Search Tree", "Keeps coupons ordered by code. Insert O(h), in-order report O(n)."));
        list.add(dsaRow("HashMap", "Finds a coupon directly by its code in O(1) on average."));
        list.add(dsaRow("Greedy Strategy", "Checks every valid coupon and picks the highest saving, O(n)."));
        list.add(dsaRow("Sorting", "ArrayList + Comparator to sort the coupon list, O(n log n)."));
        list.add(dsaRow("File Handling", "coupons.txt is loaded at startup and saved after every change."));
        card.add(list, BorderLayout.CENTER);
        card.add(treeInfo, BorderLayout.SOUTH);
        return card;
    }

    private JPanel dsaRow(String title, String description) {
        JPanel row = new JPanel(new BorderLayout(0, 1));
        row.setOpaque(false);
        row.setBorder(BorderFactory.createEmptyBorder(0, 0, 9, 0));
        row.setAlignmentX(LEFT_ALIGNMENT);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        row.add(Theme.label(title, 13, Font.BOLD, Theme.PRIMARY_DARK), BorderLayout.NORTH);
        row.add(Theme.label(description, 12, Font.PLAIN, Theme.MUTED), BorderLayout.CENTER);
        return row;
    }
}
