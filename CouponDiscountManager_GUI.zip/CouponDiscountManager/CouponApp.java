import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/**
 * Coupon & Discount Manager - Swing desktop application (the window and the start of the program).
 *
 * Usage:  java CouponApp [coupons-file] [date]
 *   coupons-file  optional, default "coupons.txt"
 *   date          optional yyyy-MM-dd, used as "today" for the validity check (default: system date)
 */
public class CouponApp extends JFrame {

    public CouponApp(CouponManager manager) {
        super("Coupon & Discount Manager");
        MainPanel main = new MainPanel(manager, this::dispose);
        setContentPane(main);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                main.saveCoupons();                           // save usage updates on exit
            }
        });
        setMinimumSize(new Dimension(1020, 680));
        setSize(1200, 780);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        String file = args.length > 0 ? args[0] : "coupons.txt";
        LocalDate today = LocalDate.now();
        if (args.length > 1) {
            try {
                today = LocalDate.parse(args[1]);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date \"" + args[1] + "\". Use yyyy-MM-dd. Using today's date.");
            }
        }
        final LocalDate checkDate = today;

        SwingUtilities.invokeLater(() -> {
            Theme.installLookAndFeel();
            CouponManager manager = new CouponManager(file, checkDate);
            manager.loadFromFile();                           // load coupons at startup
            CouponApp app = new CouponApp(manager);
            app.setVisible(true);
            if (!manager.getLoadWarnings().isEmpty()) {
                JOptionPane.showMessageDialog(app, String.join("\n", manager.getLoadWarnings()),
                        "Coupon file notice", JOptionPane.WARNING_MESSAGE);
            }
        });
    }
}
