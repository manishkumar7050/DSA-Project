import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Content of the main window: sidebar navigation, the five screens and the status bar.
 * It is a plain panel so the frame (CouponApp) stays very small.
 */
public class MainPanel extends JPanel {
    public static final String SCREEN_DASHBOARD = "Dashboard";
    public static final String SCREEN_ADD = "Add Coupon";
    public static final String SCREEN_APPLY = "Apply Coupon";
    public static final String SCREEN_MANAGE = "Manage Coupons";
    public static final String SCREEN_REPORT = "Report";

    private final CouponManager manager;
    private final CardLayout cards = new CardLayout();
    private final JPanel content = new JPanel(cards);
    private final Map<String, NavButton> navButtons = new LinkedHashMap<>();
    private final JLabel statusLabel = Theme.label(" ", 12, Font.PLAIN, Theme.MUTED);

    private final DashboardPanel dashboard;
    private final AddCouponPanel addPanel;
    private final ApplyCouponPanel applyPanel;
    private final ManageCouponsPanel managePanel;
    private final ReportPanel reportPanel;

    private final Runnable onExit;

    /** @param onExit what to do when the Exit button is pressed (the frame closes itself) */
    public MainPanel(CouponManager manager, Runnable onExit) {
        this.manager = manager;
        this.onExit = onExit;

        dashboard = new DashboardPanel(manager, this::showScreen);
        addPanel = new AddCouponPanel(manager, this::onDataChanged);
        applyPanel = new ApplyCouponPanel(manager, this::onDataChanged);
        managePanel = new ManageCouponsPanel(manager);
        reportPanel = new ReportPanel(manager);

        content.add(dashboard, SCREEN_DASHBOARD);
        content.add(addPanel, SCREEN_ADD);
        content.add(applyPanel, SCREEN_APPLY);
        content.add(managePanel, SCREEN_MANAGE);
        content.add(reportPanel, SCREEN_REPORT);

        setLayout(new BorderLayout());
        add(buildSidebar(), BorderLayout.WEST);
        add(content, BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);

        showScreen(SCREEN_DASHBOARD);
    }

    // ------------------------------------------------------------------ navigation

    public void showScreen(String name) {
        refreshAll();
        cards.show(content, name);
        for (Map.Entry<String, NavButton> entry : navButtons.entrySet()) {
            entry.getValue().setActive(entry.getKey().equals(name));
        }
    }

    private void refreshAll() {
        dashboard.refresh();
        addPanel.refresh();
        applyPanel.refresh();
        managePanel.refresh();
        reportPanel.refresh();
        statusLabel.setText("  Data file: " + manager.getFilePath().toAbsolutePath()
                + "     |     Validity checked as of: " + manager.getToday()
                + "     |     Coupons: " + manager.getTotalCount());
    }

    /** Called after a coupon was added or used: saves coupons.txt and updates every screen. */
    private void onDataChanged() {
        saveCoupons();
        refreshAll();
    }

    /** Saves coupons.txt (also called when the window is closed). */
    public void saveCoupons() {
        if (!manager.saveToFile()) {
            JOptionPane.showMessageDialog(this, manager.getLastSaveError(),
                    "Could not save coupons", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ------------------------------------------------------------------ window parts

    private JPanel buildSidebar() {
        JPanel side = new JPanel();
        side.setBackground(Theme.SIDEBAR);
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.setBorder(new EmptyBorder(24, 16, 18, 16));
        side.setPreferredSize(new Dimension(250, 0));

        JPanel brand = new JPanel(new BorderLayout(12, 0));
        brand.setOpaque(false);
        brand.setAlignmentX(LEFT_ALIGNMENT);
        brand.setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));
        brand.add(new LogoBadge(), BorderLayout.WEST);
        JPanel names = new JPanel(new BorderLayout());
        names.setOpaque(false);
        names.add(Theme.label("Coupon &", 16, Font.BOLD, Color.WHITE), BorderLayout.NORTH);
        names.add(Theme.label("Discount Manager", 16, Font.BOLD, Color.WHITE), BorderLayout.CENTER);
        brand.add(names, BorderLayout.CENTER);
        side.add(brand);
        side.add(Box.createRigidArea(new Dimension(0, 30)));

        String[] screens = {SCREEN_DASHBOARD, SCREEN_ADD, SCREEN_APPLY, SCREEN_MANAGE, SCREEN_REPORT};
        for (String screen : screens) {
            NavButton button = new NavButton(screen);
            button.setName("nav" + screen.replace(" ", ""));
            button.addActionListener(e -> showScreen(screen));
            navButtons.put(screen, button);
            side.add(button);
            side.add(Box.createRigidArea(new Dimension(0, 6)));
        }

        side.add(Box.createVerticalGlue());
        JLabel info = Theme.label("DSA Project  |  PS No. 70", 11, Font.PLAIN, new Color(0x8FA2C7));
        info.setAlignmentX(LEFT_ALIGNMENT);
        side.add(info);
        JLabel tech = Theme.label("BST  \u2022  HashMap  \u2022  Greedy", 11, Font.PLAIN, new Color(0x8FA2C7));
        tech.setAlignmentX(LEFT_ALIGNMENT);
        side.add(tech);
        side.add(Box.createRigidArea(new Dimension(0, 12)));

        JButton exit = Theme.secondaryButton("Exit");
        exit.setName("navExit");
        exit.setAlignmentX(LEFT_ALIGNMENT);
        exit.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        exit.addActionListener(e -> {
            saveCoupons();
            onExit.run();
        });
        side.add(exit);
        return side;
    }

    private JPanel buildStatusBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(Color.WHITE);
        bar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, Theme.BORDER), new EmptyBorder(6, 8, 6, 8)));
        bar.add(statusLabel, BorderLayout.CENTER);
        return bar;
    }

    /** Navigation button of the sidebar. The active screen is highlighted. */
    private static class NavButton extends JButton {
        private boolean active;
        private boolean hover;

        NavButton(String text) {
            super(text);
            setHorizontalAlignment(LEFT);
            setFont(Theme.font(Font.BOLD, 14));
            setForeground(new Color(0xCBD5E8));
            setContentAreaFilled(false);
            setFocusPainted(false);
            setOpaque(false);
            setBorder(new EmptyBorder(11, 18, 11, 12));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setAlignmentX(LEFT_ALIGNMENT);
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        void setActive(boolean active) {
            this.active = active;
            setForeground(active ? Color.WHITE : new Color(0xCBD5E8));
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (active || hover) {
                g2.setColor(active ? Theme.PRIMARY : Theme.SIDEBAR_HOVER);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    /** Small rounded logo with a percent sign. */
    private static class LogoBadge extends JPanel {
        LogoBadge() {
            setOpaque(false);
            setPreferredSize(new Dimension(46, 46));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Theme.PRIMARY);
            g2.fillRoundRect(0, 4, 44, 44, 14, 14);
            g2.setColor(Color.WHITE);
            g2.setFont(Theme.font(Font.BOLD, 24));
            String symbol = "%";
            int width = g2.getFontMetrics().stringWidth(symbol);
            g2.drawString(symbol, (44 - width) / 2, 36);
            g2.dispose();
        }
    }
}
