import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.plaf.FontUIResource;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.text.JTextComponent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Enumeration;
import java.util.function.Function;

/** Colours, fonts and small reusable Swing components, so every screen looks the same. */
public final class Theme {
    private Theme() { }

    public static final Color SIDEBAR = new Color(0x16213A);
    public static final Color SIDEBAR_HOVER = new Color(0x26355F);
    public static final Color PRIMARY = new Color(0x2F6BFF);
    public static final Color PRIMARY_DARK = new Color(0x1F55D6);
    public static final Color ACCENT = new Color(0x0E9F74);
    public static final Color ACCENT_DARK = new Color(0x0B7F5B);
    public static final Color BACKGROUND = new Color(0xF2F5FA);
    public static final Color CARD = Color.WHITE;
    public static final Color BORDER = new Color(0xDDE3EE);
    public static final Color TEXT = new Color(0x1E293B);
    public static final Color MUTED = new Color(0x64748B);
    public static final Color SUCCESS = new Color(0x15803D);
    public static final Color DANGER = new Color(0xDC2626);
    public static final Color WARNING = new Color(0xB45309);
    public static final Color TABLE_STRIPE = new Color(0xF7F9FD);
    public static final Color TABLE_SELECT = new Color(0xDCE8FF);
    public static final Color TABLE_HEADER = new Color(0xE9EFFB);

    private static final String FONT_NAME = "Segoe UI";   // falls back to the default font if missing

    public static Font font(int style, int size) {
        return new Font(FONT_NAME, style, size);
    }

    // ------------------------------------------------------------------ look and feel

    /** Uses the standard cross-platform look and feel with our font everywhere. */
    public static void installLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignored) {
            // keep the default look and feel
        }
        FontUIResource base = new FontUIResource(font(Font.PLAIN, 13));
        Enumeration<Object> keys = UIManager.getDefaults().keys();
        while (keys.hasMoreElements()) {
            Object key = keys.nextElement();
            if (key instanceof String && ((String) key).endsWith(".font")) {
                UIManager.put(key, base);
            }
        }
        UIManager.put("ComboBox.background", Color.WHITE);
        UIManager.put("OptionPane.background", Color.WHITE);
        UIManager.put("Panel.background", Color.WHITE);
    }

    // ------------------------------------------------------------------ colours for coupon status

    public static Color statusColor(String status) {
        switch (status) {
            case Coupon.STATUS_ACTIVE:   return SUCCESS;
            case Coupon.STATUS_EXPIRED:  return DANGER;
            case Coupon.STATUS_UPCOMING: return PRIMARY_DARK;
            default:                     return WARNING;      // used up
        }
    }

    public static Color statusFill(String status) {
        switch (status) {
            case Coupon.STATUS_ACTIVE:   return new Color(0xDCFCE7);
            case Coupon.STATUS_EXPIRED:  return new Color(0xFEE2E2);
            case Coupon.STATUS_UPCOMING: return new Color(0xDBEAFE);
            default:                     return new Color(0xFEF3C7);
        }
    }

    // ------------------------------------------------------------------ labels and page header

    public static JLabel label(String text, int size, int style, Color color) {
        JLabel label = new JLabel(text);
        label.setFont(font(style, size));
        label.setForeground(color);
        return label;
    }

    /** Small grey caption placed above an input field. */
    public static JLabel fieldLabel(String text) {
        return label(text, 12, Font.BOLD, MUTED);
    }

    /** Page title with a grey sub-title underneath. */
    public static JPanel pageHeader(String title, String subtitle) {
        JPanel box = new JPanel(new BorderLayout(0, 4));
        box.setOpaque(false);
        box.add(label(title, 26, Font.BOLD, TEXT), BorderLayout.NORTH);
        box.add(label(subtitle, 13, Font.PLAIN, MUTED), BorderLayout.CENTER);
        return box;
    }

    /** Base look shared by all screens. */
    public static void stylePage(JPanel page) {
        page.setBackground(BACKGROUND);
        page.setBorder(new EmptyBorder(26, 30, 22, 30));
    }

    // ------------------------------------------------------------------ input fields

    private static CompoundBorder fieldBorder(Color line) {
        return new CompoundBorder(new LineBorder(line, 1, true), new EmptyBorder(7, 10, 7, 10));
    }

    public static void styleField(JTextComponent field) {
        field.setFont(font(Font.PLAIN, 14));
        field.setForeground(TEXT);
        field.setCaretColor(PRIMARY);
        field.setBorder(fieldBorder(BORDER));
        field.setPreferredSize(new Dimension(field.getPreferredSize().width, 38));
        field.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) { field.setBorder(fieldBorder(PRIMARY)); }
            @Override public void focusLost(FocusEvent e) { field.setBorder(fieldBorder(BORDER)); }
        });
    }

    /** Creates a text field that already has the standard look. */
    public static javax.swing.JTextField fieldText(int columns) {
        javax.swing.JTextField field = new javax.swing.JTextField(columns);
        styleField(field);
        return field;
    }

    public static void styleCombo(JComboBox<?> combo) {
        combo.setFont(font(Font.PLAIN, 14));
        combo.setBackground(Color.WHITE);
        combo.setForeground(TEXT);
        combo.setPreferredSize(new Dimension(combo.getPreferredSize().width, 38));
    }

    // ------------------------------------------------------------------ cards

    /** White panel with rounded corners and a thin border. */
    public static class RoundedPanel extends JPanel {
        private final int radius;
        private final Color borderColor;

        public RoundedPanel(int radius, Color background, Color borderColor) {
            this.radius = radius;
            this.borderColor = borderColor;
            setOpaque(false);
            setBackground(background);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);
            if (borderColor != null) {
                g2.setColor(borderColor);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    public static RoundedPanel card() {
        RoundedPanel card = new RoundedPanel(18, CARD, BORDER);
        card.setBorder(new EmptyBorder(18, 22, 18, 22));
        return card;
    }

    /** Rounded panel with a blue-to-teal gradient (welcome banner). */
    public static class GradientPanel extends JPanel {
        public GradientPanel() {
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setPaint(new GradientPaint(0, 0, PRIMARY_DARK, getWidth(), getHeight(), new Color(0x0E9F9F)));
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 22, 22);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    // ------------------------------------------------------------------ buttons

    /** Rounded button with hover effect. */
    public static class AppButton extends JButton {
        public enum Kind { PRIMARY, ACCENT, SECONDARY }

        private final Kind kind;
        private boolean hover;

        public AppButton(String text, Kind kind) {
            super(text);
            this.kind = kind;
            setFont(font(Font.BOLD, 13));
            setForeground(kind == Kind.SECONDARY ? TEXT : Color.WHITE);
            setFocusPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setBorder(new EmptyBorder(10, 22, 10, 22));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color fill;
            switch (kind) {
                case PRIMARY:   fill = hover ? PRIMARY_DARK : PRIMARY; break;
                case ACCENT:    fill = hover ? ACCENT_DARK : ACCENT; break;
                default:        fill = hover ? new Color(0xEAF0FB) : Color.WHITE; break;
            }
            g2.setColor(fill);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
            if (kind == Kind.SECONDARY) {
                g2.setColor(BORDER);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    public static JButton primaryButton(String text) { return new AppButton(text, AppButton.Kind.PRIMARY); }
    public static JButton accentButton(String text) { return new AppButton(text, AppButton.Kind.ACCENT); }
    public static JButton secondaryButton(String text) { return new AppButton(text, AppButton.Kind.SECONDARY); }

    // ------------------------------------------------------------------ tables

    /** Alternating row colours; optionally colours the text of one column using colorFor(cellText). */
    public static class CellRenderer extends DefaultTableCellRenderer {
        private final int coloredColumn;
        private final Function<String, Color> colorFor;

        public CellRenderer(int coloredColumn, Function<String, Color> colorFor) {
            this.coloredColumn = coloredColumn;
            this.colorFor = colorFor;
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, false, row, column);
            setBorder(new EmptyBorder(0, 12, 0, 12));
            setFont(font(Font.PLAIN, 13));
            setForeground(TEXT);
            setBackground(isSelected ? TABLE_SELECT : (row % 2 == 0 ? CARD : TABLE_STRIPE));
            if (column == coloredColumn && colorFor != null && value != null) {
                setForeground(colorFor.apply(value.toString()));
                setFont(font(Font.BOLD, 13));
            }
            return this;
        }
    }

    private static class HeaderRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, false, false, row, column);
            setFont(font(Font.BOLD, 12));
            setForeground(TEXT);
            setBackground(TABLE_HEADER);
            setBorder(new CompoundBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER),
                    new EmptyBorder(0, 12, 0, 12)));
            return this;
        }
    }

    /** Clean flat table: no grid lines, striped rows, light header. */
    public static void styleTable(JTable table, int coloredColumn, Function<String, Color> colorFor) {
        table.setRowHeight(34);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFillsViewportHeight(true);
        table.setSelectionBackground(TABLE_SELECT);
        table.setSelectionForeground(TEXT);
        table.setDefaultRenderer(Object.class, new CellRenderer(coloredColumn, colorFor));
        JTableHeader header = table.getTableHeader();
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 38));
        header.setDefaultRenderer(new HeaderRenderer());
    }

    /** Puts a table inside a scroll pane with a thin border. */
    public static javax.swing.JScrollPane scrollable(JComponent view) {
        javax.swing.JScrollPane scroll = new javax.swing.JScrollPane(view);
        scroll.setBorder(new LineBorder(BORDER, 1));
        scroll.getViewport().setBackground(CARD);
        return scroll;
    }
}
