import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/** Screen 2: form to add a new coupon, with validation messages. */
public class AddCouponPanel extends JPanel {
    private static final String[] TYPE_NAMES = {"Percentage (%)", "Flat amount"};

    private final CouponManager manager;
    private final Runnable onDataChanged;

    private final JTextField codeField = Theme.fieldText(16);
    private final JComboBox<String> typeCombo = new JComboBox<>(TYPE_NAMES);
    private final JTextField valueField = Theme.fieldText(10);
    private final JTextField limitField = Theme.fieldText(10);
    private final JTextField startField = Theme.fieldText(10);
    private final JTextField endField = Theme.fieldText(10);
    private final JLabel valueCaption = Theme.fieldLabel("DISCOUNT VALUE (%)");
    private final JLabel messageLabel = Theme.label(" ", 13, Font.BOLD, Theme.MUTED);
    private final JLabel countHint = Theme.label(" ", 12, Font.PLAIN, Theme.MUTED);

    public AddCouponPanel(CouponManager manager, Runnable onDataChanged) {
        this.manager = manager;
        this.onDataChanged = onDataChanged;
        setLayout(new BorderLayout(0, 18));
        Theme.stylePage(this);

        codeField.setName("addCode");
        typeCombo.setName("addType");
        valueField.setName("addValue");
        limitField.setName("addLimit");
        startField.setName("addStart");
        endField.setName("addEnd");
        messageLabel.setName("addMessage");

        add(Theme.pageHeader("Add Coupon", "Create a new coupon. It is stored in the BST and the HashMap and saved to coupons.txt."),
                BorderLayout.NORTH);

        JPanel row = new JPanel(new BorderLayout(20, 0));
        row.setOpaque(false);
        row.add(buildFormCard(), BorderLayout.CENTER);
        row.add(buildRulesCard(), BorderLayout.EAST);
        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(row, BorderLayout.NORTH);
        add(top, BorderLayout.CENTER);

        Theme.styleCombo(typeCombo);
        typeCombo.addActionListener(e -> valueCaption.setText(
                typeCombo.getSelectedIndex() == 0 ? "DISCOUNT VALUE (%)" : "DISCOUNT VALUE (FIXED AMOUNT)"));
        resetFields();
        refresh();
    }

    public void refresh() {
        countHint.setText(manager.getTotalCount() + " coupon(s) currently stored");
    }

    private JPanel buildFormCard() {
        Theme.RoundedPanel card = Theme.card();
        card.setLayout(new BorderLayout(0, 14));
        card.add(Theme.label("Coupon Details", 17, Font.BOLD, Theme.TEXT), BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        addCell(form, Theme.fieldLabel("COUPON CODE"), codeField, 0, 0);
        addCell(form, Theme.fieldLabel("DISCOUNT TYPE"), typeCombo, 1, 0);
        addCell(form, valueCaption, valueField, 0, 1);
        addCell(form, Theme.fieldLabel("USAGE LIMIT (TIMES)"), limitField, 1, 1);
        addCell(form, Theme.fieldLabel("START DATE (yyyy-MM-dd)"), startField, 0, 2);
        addCell(form, Theme.fieldLabel("EXPIRY DATE (yyyy-MM-dd)"), endField, 1, 2);

        JButton addButton = Theme.primaryButton("Add Coupon");
        addButton.setName("addButton");
        addButton.addActionListener(e -> addCoupon());
        JButton clearButton = Theme.secondaryButton("Clear");
        clearButton.setName("clearButton");
        clearButton.addActionListener(e -> {
            resetFields();
            showMessage(" ", Theme.MUTED);
        });
        for (JTextField f : new JTextField[] {codeField, valueField, limitField, startField, endField}) {
            f.addActionListener(e -> addCoupon());            // Enter key adds the coupon
        }

        JPanel buttons = new JPanel();
        buttons.setOpaque(false);
        buttons.setLayout(new BoxLayout(buttons, BoxLayout.X_AXIS));
        buttons.add(addButton);
        buttons.add(javax.swing.Box.createRigidArea(new Dimension(12, 0)));
        buttons.add(clearButton);
        buttons.add(javax.swing.Box.createHorizontalGlue());

        JPanel messages = new JPanel(new BorderLayout(0, 6));
        messages.setOpaque(false);
        messages.add(messageLabel, BorderLayout.NORTH);      // validation / success message, full width
        messages.add(countHint, BorderLayout.SOUTH);

        JPanel bottom = new JPanel(new BorderLayout(0, 12));
        bottom.setOpaque(false);
        bottom.add(buttons, BorderLayout.NORTH);
        bottom.add(messages, BorderLayout.CENTER);

        card.add(form, BorderLayout.CENTER);
        card.add(bottom, BorderLayout.SOUTH);
        return card;
    }

    private JPanel buildRulesCard() {
        Theme.RoundedPanel card = Theme.card();
        card.setLayout(new BorderLayout(0, 10));
        card.setPreferredSize(new Dimension(300, 10));
        card.add(Theme.label("Coupon Rules", 17, Font.BOLD, Theme.TEXT), BorderLayout.NORTH);

        JPanel rules = new JPanel();
        rules.setOpaque(false);
        rules.setLayout(new BoxLayout(rules, BoxLayout.Y_AXIS));
        String[] lines = {                                       // <br> = manual line break
            "Every coupon code must be unique.<br>A duplicate code is rejected.",
            "No spaces or commas in a code.<br>Codes are saved in capital letters.",
            "A percentage must be between<br>0 and 100.",
            "A flat discount is a fixed amount.<br>It never exceeds the bill.",
            "The expiry date cannot be before<br>the start date.",
            "The usage limit must be at least 1.",
            "A coupon works only between its<br>dates and while uses remain."
        };
        for (String line : lines) {
            JLabel l = new JLabel("<html>\u2022  " + line + "</html>");
            l.setFont(Theme.font(Font.PLAIN, 12));
            l.setForeground(Theme.MUTED);
            l.setBorder(new EmptyBorder(0, 0, 8, 0));
            l.setAlignmentX(LEFT_ALIGNMENT);
            rules.add(l);
        }
        card.add(rules, BorderLayout.CENTER);
        return card;
    }

    /** Label above field, placed in a two-column grid. */
    private void addCell(JPanel form, JLabel caption, javax.swing.JComponent field, int col, int row) {
        JPanel cell = new JPanel(new BorderLayout(0, 5));
        cell.setOpaque(false);
        cell.add(caption, BorderLayout.NORTH);
        cell.add(field, BorderLayout.CENTER);
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = col;
        g.gridy = row;
        g.weightx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(0, col == 0 ? 0 : 8, 14, col == 0 ? 8 : 0);
        form.add(cell, g);
    }

    private void resetFields() {
        codeField.setText("");
        typeCombo.setSelectedIndex(0);
        valueField.setText("");
        limitField.setText("5");
        startField.setText(manager.getToday().toString());
        endField.setText(manager.getToday().plusDays(30).toString());
    }

    private void showMessage(String text, Color color) {
        messageLabel.setText(text);
        messageLabel.setForeground(color);
    }

    /** Validates every field, creates the coupon and adds it. Shows a message for every problem. */
    private void addCoupon() {
        String code = codeField.getText().trim();
        if (code.isEmpty()) {
            fail("Coupon code is required.");
            return;
        }
        String valueText = valueField.getText().trim();
        if (!valueText.matches("\\d+(\\.\\d+)?")) {
            fail("Discount value must be a positive number, for example 10 or 12.5.");
            return;
        }
        String limitText = limitField.getText().trim();
        if (!limitText.matches("\\d{1,9}")) {
            fail("Usage limit must be a whole number, for example 5.");
            return;
        }
        LocalDate start;
        LocalDate end;
        try {
            start = LocalDate.parse(startField.getText().trim());
        } catch (DateTimeParseException e) {
            fail("Start date must be a real date in yyyy-MM-dd format, for example 2026-12-31.");
            return;
        }
        try {
            end = LocalDate.parse(endField.getText().trim());
        } catch (DateTimeParseException e) {
            fail("Expiry date must be a real date in yyyy-MM-dd format, for example 2026-12-31.");
            return;
        }

        String type = typeCombo.getSelectedIndex() == 0 ? Coupon.PERCENT : Coupon.FLAT;
        Coupon coupon;
        try {
            coupon = new Coupon(code, type, Double.parseDouble(valueText), start, end,
                    Integer.parseInt(limitText), 0);
        } catch (IllegalArgumentException e) {
            String reason = e.getMessage();
            fail(Character.toUpperCase(reason.charAt(0)) + reason.substring(1) + ".");
            return;
        }
        if (!manager.addCoupon(coupon)) {
            fail("Duplicate coupon code rejected: " + coupon.getCode());
            return;
        }
        resetFields();
        showMessage("Coupon added: " + coupon.getCode() + " | " + coupon.describe()
                + "  (" + coupon.getStatus(manager.getToday()) + ")", Theme.SUCCESS);
        onDataChanged.run();                                   // saves coupons.txt and refreshes all screens
    }

    private void fail(String message) {
        showMessage(message, Theme.DANGER);
    }
}
