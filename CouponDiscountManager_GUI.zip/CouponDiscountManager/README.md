# Coupon & Discount Manager (PS No. 70) - Java Swing GUI

Desktop application in Java (Swing only, no Maven/Gradle). Concepts: BST, Hashing (HashMap),
Greedy, Sorting, File Handling. The original console menu (`Main`) still works.

## How to run (tested with JDK 21, as recommended in the synopsis)

Open a terminal **inside this folder** (the one that contains `coupons.txt`) and run:

    javac -d out *.java
    java -cp out CouponApp

Or simply run `run.bat` (Windows) / `./run.sh` (Linux, macOS).

Optional arguments: `java -cp out CouponApp <coupons-file> <yyyy-MM-dd>`
The date is used as "today" for the validity check, e.g. `java -cp out CouponApp coupons.txt 2027-03-01`
(useful to show an expired / not-started coupon during a demo). Without it the system date is used.

Console version (unchanged behaviour): `java -cp out Main`

Self-checking tests of the logic (use a temporary file, your coupons.txt is not touched):

    java -cp out CouponTests

## Files

| File | Purpose |
| --- | --- |
| Coupon.java | One coupon: validity check, discount calculation, used count, status (added: `getStatus`) |
| BSTNode.java | One node of the tree (unchanged) |
| BST.java | Binary Search Tree ordered by code; in-order traversal = sorted report (added: `getRoot`, `height`) |
| CouponManager.java | HashMap + BST, validation, greedy best coupon, sort, search, load/save (GUI-friendly methods added, console behaviour kept) |
| ApplyResult.java | Result of applying a coupon (shared by console and GUI) |
| Main.java | Original console menu (unchanged) |
| CouponApp.java | Swing window + `main` of the GUI |
| MainPanel.java | Sidebar navigation, the 5 screens, status bar, auto-save |
| DashboardPanel / AddCouponPanel / ApplyCouponPanel / ManageCouponsPanel / ReportPanel | The five screens |
| BstViewPanel.java | Draws the BST (Report > "BST structure" tab) |
| CouponTableModel.java, Theme.java | Shared table model, colours, fonts, buttons |
| CouponTests.java | Logic tests |
| coupons.txt | Data file, format unchanged: `code,type,value,startDate,endDate,usageLimit,usedCount` |

## Screens

1. **Dashboard** - welcome banner, total / active / expired / upcoming + used-up counts, navigation buttons, DSA summary.
2. **Add Coupon** - code, type (percentage / flat), value, usage limit, start and expiry date, with validation messages.
3. **Apply Coupon** - bill amount + code, or **Find Best Coupon** (greedy). Billing summary and a table comparing every coupon.
4. **Manage Coupons** - JTable with search (code / type / status), 5 sort orders and Refresh.
5. **Report** - counts, coupon-wise report sorted by code (BST in-order), BST picture, export to a text file.

## Where each DSA concept is used

| Concept | Where | Time |
| --- | --- | --- |
| BST | `BST.insert`, `BST.inOrderCoupons` (sorted by code, report, saving), `BstViewPanel` | insert O(h), traversal O(n) |
| HashMap | `CouponManager.couponMap` - `apply(code, bill)`, duplicate check, `findCoupon` | O(1) average |
| Greedy | `CouponManager.findBestCoupon` and the comparison table | O(n) |
| Sorting | `CouponManager.getCouponsSorted` (ArrayList + Comparator) | O(n log n) |
| Searching | `CouponManager.searchCoupons` (linear) and HashMap lookup | O(n) / O(1) |
| File handling | `loadFromFile` at startup; `saveToFile` after every add / apply and on exit | O(n) |

## Important behaviour

- Applying a coupon (manually or with Find Best Coupon) **uses it up once** and is saved to coupons.txt immediately.
- Saving rewrites coupons.txt sorted by code (same as the original program did on exit).
- Missing coupons.txt: the app starts empty and creates the file when the first coupon is saved.
  Bad lines in the file are skipped and listed in a notice window at startup.
- There is no "minimum purchase" or "maximum discount" in the project (not in the synopsis, the code or the file format),
  so the screens do not have these fields.

## The four test cases of the project description (GUI)

| # | Do this | Result |
| --- | --- | --- |
| 1 | Add Coupon: code NEW10, Percentage, value 10 | `Coupon added: NEW10 \| 10%` (SAVE10 already exists in the sample file, so use another code or remove it) |
| 2 | Apply Coupon: bill 100, code SAVE10 | `Discount: 10 \| Final bill: 90` |
| 3 | Apply Coupon: bill 100, code BAD99 | `Coupon BAD99 not found.` |
| 4 | Find Best Coupon: bill 100 (SAVE10 and FLAT15 valid) | `Best discount applied: 15 \| Final bill: 85` |
