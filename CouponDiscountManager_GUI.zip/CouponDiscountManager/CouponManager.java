import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

/**
 * Main logic class of the application (used by both the console menu and the Swing GUI).
 * It holds the BST (sorted reports) and a HashMap (direct lookup by code), validates coupons,
 * applies the greedy "best coupon" choice and loads / saves coupons.txt.
 */
public class CouponManager {

    /** Ways in which the coupon list can be sorted. */
    public enum SortBy {
        CODE_ASC("Code (A to Z) - BST in-order"),
        CODE_DESC("Code (Z to A)"),
        EXPIRY("Expiry date (soonest first)"),
        STATUS("Status (Active first)"),
        MOST_USED("Usage (most used first)");

        private final String label;
        SortBy(String label) { this.label = label; }
        @Override public String toString() { return label; }
    }

    private final BST bst = new BST();
    private final HashMap<String, Coupon> couponMap = new HashMap<>();
    private final Path filePath;
    private final LocalDate today;
    private final List<String> loadWarnings = new ArrayList<>();
    private String lastSaveError;

    public CouponManager(String filePath, LocalDate today) {
        this.filePath = Paths.get(filePath);
        this.today = today;
    }

    // ------------------------------------------------------------------ file handling

    /** Reads coupons.txt (one coupon per line) at startup. Lines starting with # are comments.
     *  Problems (missing file, bad lines, duplicates) are printed and also kept in getLoadWarnings(). */
    public void loadFromFile() {
        loadWarnings.clear();
        if (!Files.exists(filePath)) {
            warn("File " + filePath + " not found. Starting with no coupons.");
            return;
        }
        try {
            List<String> lines = Files.readAllLines(filePath, StandardCharsets.UTF_8);
            int loaded = 0;
            for (int i = 0; i < lines.size(); i++) {
                String line = lines.get(i).trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                try {
                    if (addCoupon(Coupon.fromFileLine(line))) {
                        loaded++;
                    } else {
                        warn("Line " + (i + 1) + " skipped: duplicate coupon code.");
                    }
                } catch (RuntimeException e) {
                    warn("Line " + (i + 1) + " skipped: " + e.getMessage());
                }
            }
            System.out.println(loaded + " coupon(s) loaded from " + filePath + ".");
        } catch (IOException e) {
            warn("Could not read " + filePath + ": " + e.getMessage());
        }
    }

    /** Writes all coupons (sorted by code) back to coupons.txt, including the updated used counts.
     *  Returns true on success; on failure the reason is available from getLastSaveError(). */
    public boolean saveToFile() {
        List<String> lines = new ArrayList<>();
        lines.add("# code,type,value,startDate,endDate,usageLimit,usedCount");
        for (Coupon c : bst.inOrderCoupons()) {
            lines.add(c.toFileLine());
        }
        try {
            Files.write(filePath, lines, StandardCharsets.UTF_8);
            lastSaveError = null;
            System.out.println("Coupon usage saved to " + filePath + ".");
            return true;
        } catch (IOException e) {
            lastSaveError = "Could not save " + filePath + ": " + e.getMessage();
            System.out.println(lastSaveError);
            return false;
        }
    }

    private void warn(String message) {
        loadWarnings.add(message);
        System.out.println(message);
    }

    // ------------------------------------------------------------------ add / lookup

    /** Adds a coupon to the BST and the HashMap. Returns false if the code already exists. */
    public boolean addCoupon(Coupon c) {
        if (couponMap.containsKey(c.getCode())) {
            return false;
        }
        bst.insert(c);
        couponMap.put(c.getCode(), c);
        return true;
    }

    /** Direct lookup by code through the HashMap, O(1) on average. Returns null if not found. */
    public Coupon findCoupon(String code) {
        if (code == null) return null;
        return couponMap.get(code.trim().toUpperCase());
    }

    // ------------------------------------------------------------------ apply / greedy

    /**
     * Applies a coupon to a bill. If code is empty, the greedy strategy picks the best valid coupon.
     * Otherwise the coupon is found directly through the HashMap and validated.
     * The used count of the applied coupon is increased by one.
     */
    public ApplyResult apply(String code, double bill) {
        if (!(bill > 0) || Double.isInfinite(bill)) {
            return ApplyResult.failure("Bill amount must be greater than 0.", bill);
        }
        if (code == null || code.trim().isEmpty()) {
            Coupon best = findBestCoupon(bill);
            if (best == null) {
                return ApplyResult.failure("No valid coupon available.", bill);
            }
            return useCoupon(best, bill, true);
        }
        String key = code.trim().toUpperCase();
        Coupon coupon = couponMap.get(key);                   // direct lookup, O(1) on average
        if (coupon == null) {
            return ApplyResult.failure("Coupon " + key + " not found.", bill);
        }
        String reason = coupon.getInvalidReason(today);
        if (reason != null) {
            return ApplyResult.failure("Coupon " + key + " is not valid: " + reason + ".", bill);
        }
        return useCoupon(coupon, bill, false);
    }

    private ApplyResult useCoupon(Coupon coupon, double bill, boolean autoSelected) {
        double discount = coupon.calculateDiscount(bill);
        coupon.incrementUsed();
        return ApplyResult.success(coupon.getCode(), bill, discount, autoSelected);
    }

    /** Console version of apply(): prints the result. */
    public void applyCoupon(String code, double bill) {
        ApplyResult result = apply(code, bill);
        System.out.println(result.getMessage());
        if (result.isSuccess() && result.isAutoSelected()) {
            System.out.println("Coupon used: " + result.getCouponCode());
        }
    }

    /** Greedy step: checks every coupon, skips the invalid ones and returns the valid coupon with the
     *  highest discount for this bill (null if no coupon is valid). Time: O(n). */
    public Coupon findBestCoupon(double bill) {
        Coupon best = null;
        double bestDiscount = 0;
        for (Coupon c : bst.inOrderCoupons()) {
            if (!c.isValid(today)) continue;
            double discount = c.calculateDiscount(bill);
            if (discount > bestDiscount) {                    // on a tie, the smaller code is kept
                bestDiscount = discount;
                best = c;
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ sorting / searching / reports

    /** Returns a new list of all coupons in the requested order.
     *  Code order comes straight from the BST in-order traversal (O(n)); the other orders sort an
     *  ArrayList with a Comparator (O(n log n)). Sorting is stable, so equal items stay in code order. */
    public List<Coupon> getCouponsSorted(SortBy sortBy) {
        List<Coupon> list = bst.inOrderCoupons();             // already sorted by code (A to Z)
        switch (sortBy) {
            case CODE_DESC:
                Collections.reverse(list);
                break;
            case EXPIRY:
                list.sort(Comparator.comparing(Coupon::getEndDate));
                break;
            case STATUS:
                list.sort(Comparator.comparingInt((Coupon c) -> statusRank(c.getStatus(today))));
                break;
            case MOST_USED:
                list.sort(Comparator.comparingInt(Coupon::getUsedCount).reversed());
                break;
            default:                                          // CODE_ASC: nothing more to do
                break;
        }
        return list;
    }

    /** Linear search: coupons whose code, type or status contains the text (case-insensitive),
     *  in the requested order. An empty text returns every coupon. Time: O(n). */
    public List<Coupon> searchCoupons(String text, SortBy sortBy) {
        String q = text == null ? "" : text.trim().toUpperCase();
        List<Coupon> result = new ArrayList<>();
        for (Coupon c : getCouponsSorted(sortBy)) {
            if (q.isEmpty()
                    || c.getCode().contains(q)
                    || c.getDiscountType().contains(q)
                    || c.getStatus(today).toUpperCase().contains(q)) {
                result.add(c);
            }
        }
        return result;
    }

    private static int statusRank(String status) {
        switch (status) {
            case Coupon.STATUS_ACTIVE:   return 0;
            case Coupon.STATUS_UPCOMING: return 1;
            case Coupon.STATUS_USED_UP:  return 2;
            default:                     return 3;            // expired
        }
    }

    /** The sorted report as text (all coupons sorted by code, in-order traversal of the BST). */
    public String buildSortedReport() {
        List<Coupon> coupons = bst.inOrderCoupons();
        if (coupons.isEmpty()) {
            return "No coupons available.";
        }
        List<String> lines = new ArrayList<>();
        lines.add("Coupon report (sorted by code) - date used for checking: " + today);
        lines.add(String.format("%-12s %-8s %-8s %-12s %-12s %-6s %s",
                "Code", "Type", "Value", "Start", "End", "Used", "Status"));
        for (Coupon c : coupons) {
            String reason = c.getInvalidReason(today);
            lines.add(String.format("%-12s %-8s %-8s %-12s %-12s %-6s %s",
                    c.getCode(), c.getDiscountType(), Coupon.format(c.getValue()),
                    c.getStartDate(), c.getEndDate(), c.getUsedCount() + "/" + c.getUsageLimit(),
                    reason == null ? "Valid" : "Not valid (" + reason + ")"));
        }
        return String.join(System.lineSeparator(), lines);
    }

    /** Prints all coupons sorted by code (in-order traversal of the BST). */
    public void printSortedReport() {
        System.out.println(buildSortedReport());
    }

    // ------------------------------------------------------------------ counts and getters

    public int getTotalCount() { return couponMap.size(); }

    /** Number of coupons with the given status (Coupon.STATUS_ACTIVE, STATUS_EXPIRED, ...). */
    public int countByStatus(String status) {
        int count = 0;
        for (Coupon c : couponMap.values()) {
            if (c.getStatus(today).equals(status)) count++;
        }
        return count;
    }

    public BSTNode getBstRoot() { return bst.getRoot(); }
    public int getBstHeight() { return bst.height(); }
    public LocalDate getToday() { return today; }
    public Path getFilePath() { return filePath; }
    public List<String> getLoadWarnings() { return new ArrayList<>(loadWarnings); }
    public String getLastSaveError() { return lastSaveError; }
}
