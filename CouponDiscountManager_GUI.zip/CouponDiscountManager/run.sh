#!/bin/sh
# Compiles and starts the Coupon & Discount Manager (GUI).
cd "$(dirname "$0")" || exit 1
mkdir -p out
javac -d out *.java && java -cp out CouponApp "$@"
