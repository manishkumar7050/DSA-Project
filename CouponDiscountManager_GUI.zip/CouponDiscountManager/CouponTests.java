import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

/**
 * Self-checking tests for the coupon logic (no GUI, no JUnit needed).
 * Run with:  java CouponTests
 * It works on a temporary copy of the data, so your real coupons.txt is never changed.
 */
public class CouponTests {
    private static final LocalDate TODAY = LocalDate.of(2026, 11, 25);
    private static int passed = 0;
    private static int failed = 0;

    private static final String SAMPLE =
            "# code,type,value,startDate,endDate,usageLimit,usedCount\n"
          + "SAVE10,PERCENT,10,2026-01-01,2026-12-31,5,0\n"
          + "FLAT15,FLAT,15,2026-01-01,2026-12-31,5,0\n"
          + "OLD20,PERCENT,20,2025-01-01,2025-12-31,5,0\n"
          + "USED5,FLAT,5,2026-01-01,2026-12-31,1,1\n"
          + "SOON25,PERCENT,25,2027-01-01,2027-12-31,5,0\n";

    private static void check(String name, boolean condition) {
        if (condition) {
            passed++;
            System.out.println("PASS  " + name);
        } else {
            failed++;
            System.out.println("FAIL  " + name);
        }
    }

    private static CouponManager freshManager(Path file) throws IOException {
        Files.writeString(file, SAMPLE);
        CouponManager m = new CouponManager(file.toString(), TODAY);
        m.loadFromFile();
        return m;
    }

    public static void main(String[] args) throws IOException {
        Path file = Files.createTempFile("coupons-test", ".txt");

        // 1. Adding a valid coupon  (Test case 1)
        CouponManager m = freshManager(file);
        Coupon fresh = new Coupon("NEW30", "PERCENT", 30, TODAY, TODAY.plusDays(30), 3, 0);
        check("1. add valid coupon returns true", m.addCoupon(fresh));
        check("1. total is now 6", m.getTotalCount() == 6);
        check("1. describe() text is '30%'", fresh.describe().equals("30%"));

        // 2. Adding a duplicate coupon
        check("2. duplicate code rejected", !m.addCoupon(new Coupon("save10", "FLAT", 1, TODAY, TODAY, 1, 0)));
        check("2. total unchanged (6)", m.getTotalCount() == 6);

        // 3. Applying a valid coupon  (Test case 2: 10% of 100 = 10, final 90)
        m = freshManager(file);
        ApplyResult r = m.apply("SAVE10", 100);
        check("3. valid coupon succeeds", r.isSuccess());
        check("3. message is 'Discount: 10 | Final bill: 90'", r.getMessage().equals("Discount: 10 | Final bill: 90"));
        check("3. used count increased to 1", m.findCoupon("SAVE10").getUsedCount() == 1);
        check("3. lower-case code works", m.apply("save10", 100).isSuccess());

        // 4. Applying an invalid (unknown) coupon  (Test case 3)
        r = m.apply("BAD99", 100);
        check("4. unknown coupon fails", !r.isSuccess());
        check("4. message is 'Coupon BAD99 not found.'", r.getMessage().equals("Coupon BAD99 not found."));
        check("4. final bill equals the bill (100)", r.getFinalBill() == 100);

        // 5. Applying an expired coupon (also not started / used up)
        r = m.apply("OLD20", 100);
        check("5. expired coupon rejected", !r.isSuccess() && r.getMessage().contains("expired on 2025-12-31"));
        check("5. status of OLD20 is Expired", m.findCoupon("OLD20").getStatus(TODAY).equals("Expired"));
        check("5. upcoming coupon rejected", !m.apply("SOON25", 100).isSuccess());
        check("5. used-up coupon rejected", m.apply("USED5", 100).getMessage().contains("usage limit"));

        // 6. Minimum purchase: NOT part of the existing project logic or file format -> not tested.
        System.out.println("SKIP  6. minimum purchase amount (feature does not exist in the project)");

        // 7. Automatically selecting the best coupon  (Test case 4: 10% or flat 15 on 100 -> 15, final 85)
        m = freshManager(file);
        r = m.apply("", 100);
        check("7. best coupon on 100 is FLAT15", r.isSuccess() && r.getCouponCode().equals("FLAT15"));
        check("7. message is 'Best discount applied: 15 | Final bill: 85'",
                r.getMessage().equals("Best discount applied: 15 | Final bill: 85"));
        m = freshManager(file);
        check("7. best coupon on 500 is SAVE10 (50 > 15)", m.apply("", 500).getCouponCode().equals("SAVE10"));
        check("7. flat discount never exceeds the bill", m.findCoupon("FLAT15").calculateDiscount(10) == 10);

        // 8. Sorting coupons
        m = freshManager(file);
        check("8. code A-Z", codes(m.getCouponsSorted(CouponManager.SortBy.CODE_ASC)).equals("[FLAT15, OLD20, SAVE10, SOON25, USED5]"));
        check("8. code Z-A", codes(m.getCouponsSorted(CouponManager.SortBy.CODE_DESC)).equals("[USED5, SOON25, SAVE10, OLD20, FLAT15]"));
        check("8. expiry soonest first", codes(m.getCouponsSorted(CouponManager.SortBy.EXPIRY)).equals("[OLD20, FLAT15, SAVE10, USED5, SOON25]"));
        check("8. status (Active first)", codes(m.getCouponsSorted(CouponManager.SortBy.STATUS)).equals("[FLAT15, SAVE10, SOON25, USED5, OLD20]"));
        check("8. most used first", m.getCouponsSorted(CouponManager.SortBy.MOST_USED).get(0).getCode().equals("USED5"));
        check("8. search 'save' finds SAVE10 only", codes(m.searchCoupons("save", CouponManager.SortBy.CODE_ASC)).equals("[SAVE10]"));
        check("8. search 'expired' finds OLD20", codes(m.searchCoupons("expired", CouponManager.SortBy.CODE_ASC)).equals("[OLD20]"));
        check("8. empty search returns all 5", m.searchCoupons("", CouponManager.SortBy.CODE_ASC).size() == 5);
        check("8. counts: 2 active, 1 expired, 1 upcoming, 1 used up",
                m.countByStatus("Active") == 2 && m.countByStatus("Expired") == 1
                        && m.countByStatus("Upcoming") == 1 && m.countByStatus("Used up") == 1);

        // 9. Saving and reloading
        m = freshManager(file);
        m.addCoupon(new Coupon("NEW30", "PERCENT", 30, TODAY, TODAY.plusDays(30), 3, 0));
        m.apply("SAVE10", 100);
        check("9. save succeeds", m.saveToFile());
        CouponManager reloaded = new CouponManager(file.toString(), TODAY);
        reloaded.loadFromFile();
        check("9. reloaded count is 6", reloaded.getTotalCount() == 6);
        check("9. new coupon NEW30 survived", reloaded.findCoupon("NEW30") != null);
        check("9. used count of SAVE10 survived (1)", reloaded.findCoupon("SAVE10").getUsedCount() == 1);
        CouponManager missing = new CouponManager(file + ".does-not-exist", TODAY);
        missing.loadFromFile();
        check("9. missing file handled (0 coupons, warning kept)", missing.getTotalCount() == 0 && !missing.getLoadWarnings().isEmpty());
        CouponManager unwritable = new CouponManager("/nonexistent-folder/coupons.txt", TODAY);
        check("9. save failure reported, no crash", !unwritable.saveToFile() && unwritable.getLastSaveError() != null);

        // 10. Invalid inputs
        check("10. percent over 100 rejected", rejects("A1", "PERCENT", 150, TODAY, TODAY.plusDays(1), 1));
        check("10. zero discount rejected", rejects("A2", "FLAT", 0, TODAY, TODAY.plusDays(1), 1));
        check("10. negative discount rejected", rejects("A3", "FLAT", -5, TODAY, TODAY.plusDays(1), 1));
        check("10. end before start rejected", rejects("A4", "FLAT", 5, TODAY, TODAY.minusDays(1), 1));
        check("10. usage limit 0 rejected", rejects("A5", "FLAT", 5, TODAY, TODAY.plusDays(1), 0));
        check("10. empty code rejected", rejects("  ", "FLAT", 5, TODAY, TODAY.plusDays(1), 1));
        check("10. code with space rejected", rejects("A B", "FLAT", 5, TODAY, TODAY.plusDays(1), 1));
        check("10. bad bill (0) rejected", !m.apply("SAVE10", 0).isSuccess());
        check("10. bad bill (negative) rejected", !m.apply("SAVE10", -50).isSuccess());
        check("10. bad bill (NaN) rejected", !m.apply("SAVE10", Double.NaN).isSuccess());
        Files.writeString(file, SAMPLE + "BROKEN,LINE\nBAD,PERCENT,abc,2026-01-01,2026-12-31,5,0\nSAVE10,FLAT,1,2026-01-01,2026-12-31,5,0\n");
        CouponManager messy = new CouponManager(file.toString(), TODAY);
        messy.loadFromFile();
        check("10. bad lines skipped, 5 good coupons loaded", messy.getTotalCount() == 5);
        check("10. 3 warnings (2 bad lines + 1 duplicate)", messy.getLoadWarnings().size() == 3);

        // BST
        m = freshManager(file);
        check("BST height of the sample tree is 3 levels", m.getBstHeight() == 3);

        Files.deleteIfExists(file);
        System.out.println();
        System.out.println(passed + " passed, " + failed + " failed.");
        if (failed > 0) System.exit(1);
    }

    private static String codes(List<Coupon> list) {
        return list.stream().map(Coupon::getCode).toList().toString();
    }

    private static boolean rejects(String code, String type, double value, LocalDate s, LocalDate e, int limit) {
        try {
            new Coupon(code, type, value, s, e, limit, 0);
            return false;
        } catch (IllegalArgumentException ex) {
            return true;
        }
    }
}
