import javax.swing.JPanel;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.time.LocalDate;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/** Draws the coupon BST: smaller codes on the left, larger codes on the right. Colour = coupon status. */
public class BstViewPanel extends JPanel {
    private static final int NODE_W = 96;
    private static final int NODE_H = 38;
    private static final int H_GAP = 14;
    private static final int V_GAP = 48;
    private static final int MARGIN = 30;

    /** A tree node with its drawing position (x from the in-order index, y from the depth). */
    private static class Placed {
        final BSTNode node;
        final int depth;
        final Placed parent;
        int index;

        Placed(BSTNode node, int depth, Placed parent) {
            this.node = node;
            this.depth = depth;
            this.parent = parent;
        }
    }

    private final List<Placed> placed = new ArrayList<>();
    private LocalDate today = LocalDate.now();

    public BstViewPanel() {
        setBackground(Theme.CARD);
    }

    /** Walks the tree with an iterative in-order traversal and prepares the drawing positions. */
    public void showTree(BSTNode root, LocalDate today) {
        this.today = today;
        placed.clear();
        int maxDepth = 0;
        int index = 0;
        Deque<Placed> stack = new ArrayDeque<>();
        Placed current = root == null ? null : new Placed(root, 0, null);
        while (current != null || !stack.isEmpty()) {
            while (current != null) {                         // go as far left as possible
                stack.push(current);
                BSTNode left = current.node.getLeft();
                current = left == null ? null : new Placed(left, current.depth + 1, current);
            }
            Placed visited = stack.pop();                     // visit the node
            visited.index = index++;
            placed.add(visited);
            maxDepth = Math.max(maxDepth, visited.depth);
            BSTNode right = visited.node.getRight();          // then its right subtree
            current = right == null ? null : new Placed(right, visited.depth + 1, visited);
        }
        int width = placed.isEmpty() ? 300 : 2 * MARGIN + placed.size() * (NODE_W + H_GAP);
        int height = 2 * MARGIN + (maxDepth + 1) * (NODE_H + V_GAP);
        setPreferredSize(new Dimension(width, height));
        revalidate();
        repaint();
    }

    private int nodeX(Placed p, int offsetX) {
        return offsetX + p.index * (NODE_W + H_GAP);
    }

    private int nodeY(Placed p) {
        return MARGIN + p.depth * (NODE_H + V_GAP);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        if (placed.isEmpty()) {
            g2.setColor(Theme.MUTED);
            g2.setFont(Theme.font(Font.PLAIN, 14));
            g2.drawString("The tree is empty. Add a coupon to see it here.", MARGIN, MARGIN + 10);
            g2.dispose();
            return;
        }

        int contentWidth = placed.size() * (NODE_W + H_GAP) - H_GAP;
        int offsetX = Math.max(MARGIN, (getWidth() - contentWidth) / 2);   // centre the tree

        // edges first, so the nodes are drawn on top of them
        g2.setColor(new Color(0x94A3B8));
        g2.setStroke(new BasicStroke(1.8f));
        for (Placed p : placed) {
            if (p.parent != null) {
                g2.drawLine(nodeX(p.parent, offsetX) + NODE_W / 2, nodeY(p.parent) + NODE_H,
                        nodeX(p, offsetX) + NODE_W / 2, nodeY(p));
            }
        }

        for (Placed p : placed) {
            Coupon coupon = p.node.getCoupon();
            int x = nodeX(p, offsetX);
            int y = nodeY(p);
            String status = coupon.getStatus(today);
            g2.setColor(Theme.statusFill(status));
            g2.fillRoundRect(x, y, NODE_W, NODE_H, 14, 14);
            g2.setColor(Theme.statusColor(status));
            g2.setStroke(new BasicStroke(2f));
            g2.drawRoundRect(x, y, NODE_W, NODE_H, 14, 14);

            g2.setFont(Theme.font(Font.BOLD, 13));
            FontMetrics fm = g2.getFontMetrics();
            String text = fit(coupon.getCode(), fm, NODE_W - 12);
            g2.setColor(Theme.TEXT);
            g2.drawString(text, x + (NODE_W - fm.stringWidth(text)) / 2, y + (NODE_H + fm.getAscent()) / 2 - 3);

            if (p.depth == 0) {                               // mark the root
                g2.setFont(Theme.font(Font.BOLD, 11));
                g2.setColor(Theme.MUTED);
                FontMetrics small = g2.getFontMetrics();
                g2.drawString("ROOT", x + (NODE_W - small.stringWidth("ROOT")) / 2, y - 8);
            }
        }
        g2.dispose();
    }

    /** Shortens the text with ".." if it is wider than the node. */
    private static String fit(String text, FontMetrics fm, int maxWidth) {
        if (fm.stringWidth(text) <= maxWidth) return text;
        String cut = text;
        while (cut.length() > 1 && fm.stringWidth(cut + "..") > maxWidth) {
            cut = cut.substring(0, cut.length() - 1);
        }
        return cut + "..";
    }
}
