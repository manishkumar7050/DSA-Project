/** One node of the Binary Search Tree. It holds a Coupon and links to a left and a right child. */
public class BSTNode {
    private final Coupon coupon;
    private BSTNode left;
    private BSTNode right;

    public BSTNode(Coupon coupon) {
        this.coupon = coupon;
    }

    public Coupon getCoupon() { return coupon; }
    public BSTNode getLeft() { return left; }
    public BSTNode getRight() { return right; }
    public void setLeft(BSTNode left) { this.left = left; }
    public void setRight(BSTNode right) { this.right = right; }
}
