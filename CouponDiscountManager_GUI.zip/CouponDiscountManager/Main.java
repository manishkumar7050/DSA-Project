import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

/**
 * Coupon & Discount Manager - console application.
 *
 * Usage:  java Main [coupons-file] [date]
 *   coupons-file  optional, default "coupons.txt"
 *   date          optional yyyy-MM-dd, used as "today" for the validity check (default: system date)
 */
public class Main {
    private static final Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        String file = args.length > 0 ? args[0] : "coupons.txt";
        LocalDate today = LocalDate.now();
        if (args.length > 1) {
            try {
                today = LocalDate.parse(args[1]);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date \"" + args[1] + "\". Use yyyy-MM-dd. Using today's date.");
            }
        }

        CouponManager manager = new CouponManager(file, today);
        manager.loadFromFile();                                   // 1. load coupons at startup

        boolean running = true;
        while (running) {
            System.out.println();
            System.out.println("===== Coupon & Discount Manager =====");
            System.out.println("1. Add a coupon");
            System.out.println("2. Apply a coupon to a bill (leave the code empty for the best coupon)");
            System.out.println("3. Show sorted coupon report");
            System.out.println("4. Exit (saves usage to " + file + ")");
            String choice = ask("Choose an option (1-4): ");
            if (choice == null) break;                            // end of input
            switch (choice.trim()) {
                case "1": addCouponFlow(manager); break;
                case "2": applyFlow(manager); break;
                case "3": manager.printSortedReport(); break;
                case "4": running = false; break;
                default: System.out.println("Invalid option. Please enter 1, 2, 3 or 4.");
            }
        }
        manager.saveToFile();                                     // save usage updates on exit
        System.out.println("Goodbye!");
    }

    private static void addCouponFlow(CouponManager manager) {
        try {
            String code = ask("Coupon code: ");
            String type = ask("Discount type (P = percentage, F = flat): ");
            String value = ask("Discount value: ");
            String start = ask("Start date (yyyy-MM-dd): ");
            String end = ask("End date (yyyy-MM-dd): ");
            String limit = ask("Usage limit: ");
            if (code == null || type == null || value == null || start == null || end == null || limit == null) return;

            String t = type.trim().toUpperCase();
            if (t.equals("P")) t = Coupon.PERCENT;
            if (t.equals("F")) t = Coupon.FLAT;

            Coupon coupon = new Coupon(code, t, Double.parseDouble(value.trim()),
                    LocalDate.parse(start.trim()), LocalDate.parse(end.trim()),
                    Integer.parseInt(limit.trim()), 0);
            if (manager.addCoupon(coupon)) {
                System.out.println("Coupon added: " + coupon.getCode() + " | " + coupon.describe());
            } else {
                System.out.println("Duplicate coupon code rejected: " + coupon.getCode());
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid number entered. Coupon not added.");
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date entered (use yyyy-MM-dd). Coupon not added.");
        } catch (IllegalArgumentException e) {
            System.out.println("Coupon not added: " + e.getMessage() + ".");
        }
    }

    private static void applyFlow(CouponManager manager) {
        String code = ask("Enter coupon code (press Enter for the best coupon): ");
        String bill = ask("Enter bill amount: ");
        if (code == null || bill == null) return;
        try {
            double amount = Double.parseDouble(bill.trim());
            if (!(amount > 0) || Double.isInfinite(amount)) {
                System.out.println("Bill amount must be greater than 0.");
                return;
            }
            manager.applyCoupon(code, amount);
        } catch (NumberFormatException e) {
            System.out.println("Invalid bill amount.");
        }
    }

    /** Prints a prompt and reads one line; returns null at the end of the input. */
    private static String ask(String prompt) {
        System.out.print(prompt);
        return in.hasNextLine() ? in.nextLine() : null;
    }
}
