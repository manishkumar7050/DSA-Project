/**
 * Result of applying a coupon to a bill. The console menu prints its message and the GUI
 * shows it in the billing summary, so both use exactly the same logic and wording.
 */
public class ApplyResult {
    private final boolean success;
    private final String message;
    private final String couponCode;      // null when no coupon was applied
    private final double billAmount;
    private final double discount;
    private final double finalBill;
    private final boolean autoSelected;   // true when the greedy "best coupon" choice was used

    private ApplyResult(boolean success, String message, String couponCode,
                        double billAmount, double discount, boolean autoSelected) {
        this.success = success;
        this.message = message;
        this.couponCode = couponCode;
        this.billAmount = billAmount;
        this.discount = discount;
        this.finalBill = billAmount - discount;
        this.autoSelected = autoSelected;
    }

    /** A coupon was applied. */
    public static ApplyResult success(String couponCode, double bill, double discount, boolean autoSelected) {
        String text = (autoSelected ? "Best discount applied: " : "Discount: ")
                + Coupon.format(discount) + " | Final bill: " + Coupon.format(bill - discount);
        return new ApplyResult(true, text, couponCode, bill, discount, autoSelected);
    }

    /** No coupon was applied (unknown code, invalid coupon, bad bill ...). The bill stays unchanged. */
    public static ApplyResult failure(String message, double bill) {
        return new ApplyResult(false, message, null, bill, 0, false);
    }

    public boolean isSuccess() { return success; }
    public String getMessage() { return message; }
    public String getCouponCode() { return couponCode; }
    public double getBillAmount() { return billAmount; }
    public double getDiscount() { return discount; }
    public double getFinalBill() { return finalBill; }
    public boolean isAutoSelected() { return autoSelected; }
}
