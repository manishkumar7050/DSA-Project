import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.TableColumnModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/** Screen 5: coupon counts, the sorted coupon-wise report and a picture of the BST. */
public class ReportPanel extends JPanel {
    private final CouponManager manager;
    private final CouponTableModel tableModel;
    private final BstViewPanel bstView = new BstViewPanel();
    private final JLabel totalValue = Theme.label("0", 26, Font.BOLD, Theme.PRIMARY);
    private final JLabel activeValue = Theme.label("0", 26, Font.BOLD, Theme.SUCCESS);
    private final JLabel expiredValue = Theme.label("0", 26, Font.BOLD, Theme.DANGER);
    private final JLabel upcomingValue = Theme.label("0", 26, Font.BOLD, Theme.PRIMARY_DARK);
    private final JLabel usedUpValue = Theme.label("0", 26, Font.BOLD, Theme.WARNING);
    private final JLabel bstInfo = Theme.label(" ", 12, Font.PLAIN, Theme.MUTED);

    public ReportPanel(CouponManager manager) {
        this.manager = manager;
        this.tableModel = new CouponTableModel(manager.getToday(), true);
        setLayout(new BorderLayout(0, 16));
        Theme.stylePage(this);

        totalValue.setName("repTotal");
        activeValue.setName("repActive");
        expiredValue.setName("repExpired");
        upcomingValue.setName("repUpcoming");
        usedUpValue.setName("repUsedUp");

        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.add(Theme.pageHeader("Coupon Report",
                "Coupon-wise information, sorted by code with an in-order traversal of the BST."), BorderLayout.CENTER);
        JButton exportButton = Theme.secondaryButton("Export Report (.txt)");
        exportButton.setName("repExport");
        exportButton.addActionListener(e -> exportReport());
        JPanel exportBox = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 6));
        exportBox.setOpaque(false);
        exportBox.add(exportButton);
        header.add(exportBox, BorderLayout.EAST);

        JPanel top = new JPanel(new BorderLayout(0, 16));
        top.setOpaque(false);
        top.add(header, BorderLayout.NORTH);
        top.add(buildStatRow(), BorderLayout.CENTER);
        add(top, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(Theme.font(Font.BOLD, 13));
        tabs.setBackground(Theme.BACKGROUND);
        tabs.addTab("Coupon-wise report (sorted by code)", buildTableCard());
        tabs.addTab("BST structure", buildBstCard());
        add(tabs, BorderLayout.CENTER);

        refresh();
    }

    private JPanel buildStatRow() {
        JPanel row = new JPanel(new GridLayout(1, 5, 12, 0));
        row.setOpaque(false);
        row.add(chip("Total", totalValue));
        row.add(chip("Active", activeValue));
        row.add(chip("Expired", expiredValue));
        row.add(chip("Upcoming", upcomingValue));
        row.add(chip("Used up", usedUpValue));
        return row;
    }

    private JPanel chip(String caption, JLabel value) {
        Theme.RoundedPanel chip = new Theme.RoundedPanel(14, Theme.CARD, Theme.BORDER);
        chip.setLayout(new BorderLayout(0, 0));
        chip.setBorder(javax.swing.BorderFactory.createEmptyBorder(8, 16, 8, 16));
        chip.add(Theme.label(caption, 12, Font.BOLD, Theme.MUTED), BorderLayout.NORTH);
        chip.add(value, BorderLayout.CENTER);
        return chip;
    }

    private JPanel buildTableCard() {
        JTable table = new JTable(tableModel);
        table.setName("reportTable");
        Theme.styleTable(table, CouponTableModel.STATUS_COLUMN, Theme::statusColor);
        TableColumnModel columns = table.getColumnModel();
        int[] widths = {130, 100, 110, 110, 90, 90, 240};
        for (int i = 0; i < widths.length; i++) {
            columns.getColumn(i).setPreferredWidth(widths[i]);
        }
        columns.getColumn(CouponTableModel.STATUS_COLUMN).setMinWidth(100);   // "Upcoming" must fit
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Theme.CARD);
        card.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 12, 12, 12));
        card.add(Theme.scrollable(table), BorderLayout.CENTER);
        return card;
    }

    private JPanel buildBstCard() {
        JPanel card = new JPanel(new BorderLayout(0, 8));
        card.setBackground(Theme.CARD);
        card.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JPanel legend = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0));
        legend.setOpaque(false);
        legend.add(bstInfo);
        for (String status : new String[] {Coupon.STATUS_ACTIVE, Coupon.STATUS_EXPIRED,
                Coupon.STATUS_UPCOMING, Coupon.STATUS_USED_UP}) {
            JLabel l = Theme.label("  " + status + "  ", 11, Font.BOLD, Theme.statusColor(status));
            l.setOpaque(true);
            l.setBackground(Theme.statusFill(status));
            l.setBorder(javax.swing.BorderFactory.createLineBorder(Theme.statusColor(status)));
            legend.add(l);
        }
        card.add(legend, BorderLayout.NORTH);
        card.add(Theme.scrollable(bstView), BorderLayout.CENTER);
        return card;
    }

    /** Rebuilds the counts, the table and the tree picture. */
    public void refresh() {
        totalValue.setText(String.valueOf(manager.getTotalCount()));
        activeValue.setText(String.valueOf(manager.countByStatus(Coupon.STATUS_ACTIVE)));
        expiredValue.setText(String.valueOf(manager.countByStatus(Coupon.STATUS_EXPIRED)));
        upcomingValue.setText(String.valueOf(manager.countByStatus(Coupon.STATUS_UPCOMING)));
        usedUpValue.setText(String.valueOf(manager.countByStatus(Coupon.STATUS_USED_UP)));
        tableModel.setCoupons(manager.getCouponsSorted(CouponManager.SortBy.CODE_ASC));
        bstView.showTree(manager.getBstRoot(), manager.getToday());
        bstInfo.setText("Nodes: " + manager.getTotalCount() + "   Height: " + manager.getBstHeight() + " level(s)   ");
    }

    /** Saves the sorted report and the totals as a text file chosen by the user. */
    private void exportReport() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Export coupon report");
        chooser.setSelectedFile(new File("coupon_report.txt"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        File file = chooser.getSelectedFile();
        if (file.exists() && JOptionPane.showConfirmDialog(this, file.getName() + " already exists. Replace it?",
                "Export report", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) {
            return;
        }
        String nl = System.lineSeparator();
        String text = manager.buildSortedReport() + nl + nl
                + "Total coupons: " + manager.getTotalCount()
                + " | Active: " + manager.countByStatus(Coupon.STATUS_ACTIVE)
                + " | Expired: " + manager.countByStatus(Coupon.STATUS_EXPIRED)
                + " | Upcoming: " + manager.countByStatus(Coupon.STATUS_UPCOMING)
                + " | Used up: " + manager.countByStatus(Coupon.STATUS_USED_UP) + nl;
        try {
            Files.write(file.toPath(), text.getBytes(StandardCharsets.UTF_8));
            JOptionPane.showMessageDialog(this, "Report saved to " + file.getAbsolutePath(),
                    "Export report", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Could not save the report: " + e.getMessage(),
                    "Export report", JOptionPane.ERROR_MESSAGE);
        }
    }
}
