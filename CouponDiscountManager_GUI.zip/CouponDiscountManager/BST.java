import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/** Binary Search Tree that organizes coupons by code. */
public class BST {
    private BSTNode root;

    /** Inserts a coupon by comparing codes. Returns false (and inserts nothing) for a duplicate code.
     *  Time: O(h), where h is the height of the tree. */
    public boolean insert(Coupon coupon) {
        if (root == null) {
            root = new BSTNode(coupon);
            return true;
        }
        BSTNode current = root;
        while (true) {
            int cmp = coupon.getCode().compareTo(current.getCoupon().getCode());
            if (cmp == 0) {
                return false;                       // duplicate code
            } else if (cmp < 0) {                   // smaller code goes to the left
                if (current.getLeft() == null) {
                    current.setLeft(new BSTNode(coupon));
                    return true;
                }
                current = current.getLeft();
            } else {                                // larger code goes to the right
                if (current.getRight() == null) {
                    current.setRight(new BSTNode(coupon));
                    return true;
                }
                current = current.getRight();
            }
        }
    }

    /** In-order traversal (left, node, right): returns the coupons sorted by code. Time: O(n). */
    public List<Coupon> inOrderCoupons() {
        List<Coupon> result = new ArrayList<>();
        Deque<BSTNode> stack = new ArrayDeque<>();   // iterative, so a skewed tree cannot overflow the call stack
        BSTNode current = root;
        while (current != null || !stack.isEmpty()) {
            while (current != null) {
                stack.push(current);
                current = current.getLeft();
            }
            current = stack.pop();
            result.add(current.getCoupon());
            current = current.getRight();
        }
        return result;
    }

    /** Root node (used by the GUI to draw the tree). Null when the tree is empty. */
    public BSTNode getRoot() {
        return root;
    }

    /** Height of the tree counted in levels (0 for an empty tree, 1 for a single node).
     *  Level-order walk, so a skewed tree cannot overflow the call stack. Time: O(n). */
    public int height() {
        int levels = 0;
        Deque<BSTNode> queue = new ArrayDeque<>();
        if (root != null) queue.add(root);
        while (!queue.isEmpty()) {
            levels++;
            for (int i = queue.size(); i > 0; i--) {
                BSTNode node = queue.poll();
                if (node.getLeft() != null) queue.add(node.getLeft());
                if (node.getRight() != null) queue.add(node.getRight());
            }
        }
        return levels;
    }
}
